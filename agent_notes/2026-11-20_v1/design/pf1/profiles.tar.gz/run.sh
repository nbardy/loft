#!/bin/bash
set -e
root=/Users/nicholasbardy/git/loft
work=/Users/nicholasbardy/git/_wt/loft-pf1
out="$root/out/meta/pf1"
cd "$work"
pair() {
    local s=$1 v=$2 file time_args=() set_args=() n
    case $s in hermit) file=hermit; n=300; set_args=(--set count=20);; shrine) file=coral_shrine; n=100; time_args=(--time 0);; esac
    local msl="$out/$s-$v-msl"
    mkdir -p "$msl"
    tools/gpu_lock.sh env PF1_PAIR="$v" PF1_MSL="$msl" target/lab/loft profile "engines/$file.loft" "${set_args[@]}" --size 1280x800 --timestamps ring --warmup 30 --frames "$n" "${time_args[@]}" --json "$out/$s-$v.json" > "$out/$s-$v.log" 2>&1
}
for v in trust-shade trust-trace fullscreen contract-off hdr-wide hdr-bypass reuse-shadow; do
  for s in hermit shrine; do pair "$s" "$v"; done
done
for v in no-sky no-noise unroll; do pair hermit "$v"; done
for v in half-lip lantern-off branch-off; do pair shrine "$v"; done
