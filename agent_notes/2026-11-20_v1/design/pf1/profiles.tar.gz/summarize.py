from pathlib import Path
import json, math
import numpy as np
from PIL import Image
p=Path(__file__).resolve().parent
N=1024000
passes=['Cull','Vis','Shadow','Classify','Shade','Present']
q=lambda a,k:float(np.quantile(a,k,method='inverted_cdf'))
r=lambda x:round(x,6)
def stats(a):return [r(q(a,k)) for k in (.5,.95)]
def read(path):return json.loads(path.read_text())
result={'baseline':{},'aovs':read(p/'aovs.json'),'coverage':{},'pairs':{}}
for scene,kinds in [('hermit',5),('shrine',4)]:
    j=read(p/f'{scene}-baseline.json')
    times=np.array(j['gpu_frame_ms'])
    result['baseline'][scene]={k:j[k] for k in ('adapter','control_p50_ms','passes','modules','shader_sha256')}
    ticks=np.array([s['ticks'] for s in j['frame_stamps']],dtype='int64')
    ns_per_tick=times[0]*1e6/(ticks[0,-1]-ticks[0,0])
    data=result['baseline'][scene]
    data.update(frame=stats(times),commands=j['frame_stamps'][0]['commands'],attribution=list(map(stats,np.transpose(j['gpu_pass_ms']))),raw_pairs=list(map(stats,np.transpose((ticks[:,1::2]-ticks[:,::2])*ns_per_tick/1e6))),period_ns=ns_per_tick)
    for f in sorted((p/f'{scene}-trust-shade').glob('vis-args*.bin')):
        a=np.fromfile(f,dtype='<u4')
        vis=a[:N*2:2].reshape(800,1280)
        mask=vis!=0xffffffff
        ids=vis>>24
        tile_counts=a[2*N:2*N+3*kinds].reshape(kinds,3)[:,0].tolist()
        # Verify every GPU indirect count against the independent full-resolution visibility readback.
        occupied=[int(np.sum(ids==k)) for k in range(kinds)]
        counts=[int(np.sum(np.any((ids==k).reshape(100,8,160,8),axis=(1,3)))) for k in range(kinds)]
        assert tile_counts==counts
        draws=a[2*N+3*kinds:].reshape(kinds,-1)[:,1].tolist()
        result['coverage'][f'{scene}@{f.stem.split("-")[-1]}']=dict(tiles=counts,hits=occupied,draw_rows=draws,shade_reads=64*sum(counts),hdr_store_Bpp=r(8*sum(occupied)/N),shade_vis_Bpp=r(8*64*sum(counts)/N))
    for f in sorted(p.glob(f'{scene}-*.json')):
        if f.name.endswith('-baseline.json') or f.name.endswith('-show.json'):continue
        j=read(f)
        if not isinstance(j,list):continue
        v=f.stem[len(scene)+1:]
        sums=[]
        for arm in j:
            frames=arm['stamps']
            cols=list(zip(*[x['pass_ms'] for x in frames]))
            ps=[k for k in passes if not(arm['arm']=='B' and v=='reuse-shadow' and k=='Shadow')]
            sums.append(dict(arm=arm['arm'],tri=arm['triangle'],frame=stats([x['gpu_ms'] for x in frames]),passes=dict(zip(ps,map(stats,cols))),commands=frames[0]['commands']))
        a1,b1,b2,a2=sums
        def delta(a,b):
            return [(a[i]-b[i]) for i in range(2)]
        def combine(a,b):return [r((x+y)/2) for x,y in zip(a,b)]
        deltas={k:combine(delta(a1['passes'][k],b1['passes'].get(k,[0,0])),delta(a2['passes'][k],b2['passes'].get(k,[0,0]))) for k in passes}
        pixels=[int(np.any(np.array(Image.open(f.with_suffix('')/f'A-{t}.png'))!=np.array(Image.open(f.with_suffix('')/f'B-{t}.png')),axis=2).sum()) for t in [0,4,9]]
        result['pairs'][f.stem]=dict(arms=sums,frame_gain=combine(delta(a1['frame'],b1['frame']),delta(a2['frame'],b2['frame'])),pass_gain=deltas,pixel_changes=pixels)
        z=result['pairs'][f.stem]
        print(f.stem,'frame',z['frame_gain'],'vis/sh/shade/post',[round(deltas[k][0],3) for k in ['Vis','Shadow','Shade','Present']],'pixels',pixels,'tri',round(max(x['tri'] for x in sums),3))
print('coverage',result['coverage'])
(p/'score.json').write_text(json.dumps(result,indent=2))
