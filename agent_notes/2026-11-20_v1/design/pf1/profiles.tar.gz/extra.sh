#!/bin/bash
set -e
root=/Users/nicholasbardy/git/loft
work=/Users/nicholasbardy/git/_wt/loft-pf1
out="$root/out/meta/pf1"
cd "$work"
pair() {
  local s=$1 v=$2 order=$3 file number folder args=() extra=()
  case "$s" in hermit) file=hermit; number=300; args=(--set count=20);; shrine) file=coral_shrine; number=100; args=(--time 0);; esac
  folder="$out"
  if [ -n "$order" ]; then folder="$out/$order"; extra=("PF1_ORDER=$order"); fi
  mkdir -p "$folder/$s-$v-msl"
  tools/gpu_lock.sh env "PF1_PAIR=$v" "PF1_MSL=$folder/$s-$v-msl" "${extra[@]}" target/lab/loft-pf1-extra profile "engines/$file.loft" "${args[@]}" --size 1280x800 --timestamps ring --warmup 30 --frames "$number" --json "$folder/$s-$v.json" > "$folder/$s-$v.log" 2>&1
}
for v in hdr-hot loop-only march4; do
  for s in shrine hermit; do pair "$s" "$v" ""; done
done
pair hermit sky-table ""
for order in ascending descending; do
  for v in loop-only trust-trace march4 reuse-shadow; do pair shrine "$v" "$order"; done
done
