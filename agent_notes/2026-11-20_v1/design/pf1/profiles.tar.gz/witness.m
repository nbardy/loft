#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <stdio.h>
int main(void) {
    @autoreleasepool {
        id<MTLDevice> d=MTLCreateSystemDefaultDevice();
        for (id<MTLCounterSet> set in d.counterSets) {
            printf("counter set %s:",set.name.UTF8String);
            for (id<MTLCounter> c in set.counters) printf(" %s",c.name.UTF8String);
            puts("");
        }
        for (NSString *pragma in @[@"",@"#pragma METAL fp contract(off)\n",@"#pragma METAL fp contract(fast)\n"]) {
            MTLCompileOptions *opt=[MTLCompileOptions new];
            // Match the 30.0.1 HAL version after checking actual capture (override via argv/env).
            opt.languageVersion=(MTLLanguageVersion)strtoul(getenv("PF1_MTL_VERSION"),NULL,10);
            opt.preserveInvariance=YES;
            NSString *s=[pragma stringByAppendingString:@"#include <metal_stdlib>\nusing namespace metal;\nkernel void witness(device const float* a [[buffer(0)]],device uint* bits [[buffer(1)]]) { bits[0]=as_type<uint>(a[0]*a[1]+a[2]); }"];
            NSError *err=nil;
            id<MTLLibrary> lib=[d newLibraryWithSource:s options:opt error:&err];
            if (!lib) { NSLog(@"%@",err); return 2; }
            id<MTLComputePipelineState> pipe=[d newComputePipelineStateWithFunction:[lib newFunctionWithName:@"witness"] error:&err];
            if (!pipe) {NSLog(@"%@",err);return 2;}
            uint32_t input[]={0x3f800001,0x3f7ffffe,0xbf800000};
            id<MTLBuffer> in=[d newBufferWithBytes:input length:12 options:MTLResourceStorageModeShared];
            id<MTLBuffer> out=[d newBufferWithLength:4 options:MTLResourceStorageModeShared];
            id<MTLCommandQueue> q=[d newCommandQueue];
            id<MTLCommandBuffer> cmd=[q commandBuffer];
            id<MTLComputeCommandEncoder> enc=[cmd computeCommandEncoder];
            [enc setComputePipelineState:pipe]; [enc setBuffer:in offset:0 atIndex:0]; [enc setBuffer:out offset:0 atIndex:1];
            [enc dispatchThreadgroups:MTLSizeMake(1,1,1) threadsPerThreadgroup:MTLSizeMake(1,1,1)]; [enc endEncoding];
            [cmd commit]; [cmd waitUntilCompleted]; if (cmd.error) {NSLog(@"%@",cmd.error);return 2;}
            printf("lang=%lu math=%ld invariant=%d %s result=0x%08x\n", (unsigned long)opt.languageVersion, (long)opt.mathMode,opt.preserveInvariance,pragma.length?pragma.UTF8String:"default",*(uint32_t*)out.contents);
        }
    }
}
