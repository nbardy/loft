from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import json
p=Path(__file__).resolve().parent
stats={}
for s,title in [('hermit','Hermit · 20'),('coral_shrine','Coral Shrine')]:
    sheet=Image.new('RGB',(1536,752),(21,24,29))
    draw=ImageDraw.Draw(sheet)
    font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',19)
    small=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',16)
    draw.text((12,7),title+'    |    1280 × 800 per source frame',font=font,fill='white')
    for j,(key,label) in enumerate([('sdf_steps','SDF steps · blue 0  /  green 96  /  red 192'),('lipschitz_ratio','Secant / L · navy ≤0.3  /  green ≈1  /  red >1')]):
        y=34+j*359
        draw.text((12,y),label,font=small,fill='white')
        for i,t in enumerate((0,4,9)):
            x=i*512
            im=Image.open(p/f'{s}-{key}-{t}.png').convert('RGB')
            sheet.paste(im.resize((512,320),Image.Resampling.LANCZOS),(x,y+32))
            draw.text((x+472,y+8),f'{t} s',font=small,fill='white')
    sheet.save(p/f'{s}-aovs.webp', quality=95,method=6)
    for t in (0,4,9):
        a,l=(np.array(Image.open(p/f'{s}-{k}-{t}.png').convert('RGB')).astype(int) for k in ('sdf_steps','lipschitz_ratio'))
        occupied=a.any(axis=2)
        traced=occupied & (a[:,:,1]>0) | (a[:,:,0]>0)
        # Recover the nearest of the 193 linearly encoded palette values, including half/UNORM quantization.
        r,g,b=a.transpose(2,0,1)
        steps=np.rint(np.where(r>0,96+96*r/255,96*g/255)).astype(int)
        masklow=(l[:,:,0]==0)&(l[:,:,1]==0)&(l[:,:,2]==89)
        flat=steps[traced]
        stats[f'{s}@{t}']=dict(occupied=int(occupied.sum()),traced=int(traced.sum()),steps_mean=float(flat.mean()),steps_p50_p90_p95_p99_max=np.percentile(flat,[50,90,95,99,100],method='nearest').tolist(),blue_ratio_traced=int((masklow&traced).sum()),red_ratio_traced=int(((l[:,:,0]>0)&traced).sum()))
(p/'aovs.json').write_text(json.dumps(stats,indent=2))
print(json.dumps(stats,indent=2))
