#pragma METAL fp contract(off)
// language: metal3.2
#include <metal_stdlib>
#include <simd/simd.h>

using metal::uint;

struct _mslBufferSizes {
    uint size1;
    uint size5;
};

struct Frame {
    metal::float4x4 view_proj;
    metal::float4x4 inv_view_proj;
    metal::float4 eye;
    metal::float4 sun;
    metal::uint4 size;
    metal::uint4 cold;
    metal::float4x4 light_vp;
};
struct LoftXform {
    metal::float3x3 r;
    metal::float3 t;
};
struct Row {
    LoftXform r_pose;
    float r_len;
    float r_level;
    char _pad3[8];
    metal::float3 loft_lo;
    metal::packed_float3 loft_hi;
    float loft_lip;
};
struct KindParams {
    uint kind_id;
    uint base;
    uint n_rows;
    uint pad;
};
typedef float type_8[1];
typedef uint type_9[1];
struct Bsdf {
    metal::float3 l0_0_;
};
struct type_11 {
    uint inner[36];
};
struct type_13 {
    metal::float3 inner[4];
};
constant uint LOFT_NONCE = 4294967295u;
constant uint LOFT_EMPTY = 4294967295u;
constant uint STRIDE = 21u;
constant float loft_const_branch_taper = 0.034375;
constant type_11 LOFT_CUBE = type_11 {{1u, 3u, 7u, 1u, 7u, 5u, 0u, 6u, 2u, 0u, 4u, 6u, 2u, 6u, 7u, 2u, 7u, 3u, 0u, 1u, 5u, 0u, 5u, 4u, 4u, 5u, 7u, 4u, 7u, 6u, 0u, 2u, 3u, 0u, 3u, 1u}};
constant type_13 LOFT_TETRA = type_13 {{metal::float3(1.0, -1.0, -1.0), metal::float3(-1.0, -1.0, 1.0), metal::float3(-1.0, 1.0, -1.0), metal::float3(1.0, 1.0, 1.0)}};

metal::float3 loft_xf_pt(
    LoftXform x,
    metal::float3 p
) {
    return (x.r * p) + x.t;
}

metal::float3 loft_xf_vec(
    LoftXform x_1,
    metal::float3 v
) {
    return x_1.r * v;
}

LoftXform loft_xf_inv(
    LoftXform x_2
) {
    metal::float3x3 rt = metal::transpose(x_2.r);
    return LoftXform {rt, -((rt * x_2.t))};
}

metal::float3 pf1_contract_off(
    metal::float2 px,
    constant Frame& frame
) {
    uint _e5 = frame.size.x;
    uint _e16 = frame.size.y;
    metal::float2 ndc = metal::float2(((px.x / static_cast<float>(_e5)) * 2.0) - 1.0, 1.0 - ((px.y / static_cast<float>(_e16)) * 2.0));
    metal::float4x4 _e26 = frame.inv_view_proj;
    metal::float4 far = _e26 * metal::float4(ndc, 1.0, 1.0);
    metal::float4 _e37 = frame.eye;
    return metal::normalize((far.xyz / metal::float3(far.w)) - _e37.xyz);
}

Row load_row(
    uint i_2,
    device type_8 const& rows,
    constant _mslBufferSizes& _buffer_sizes
) {
    uint o = i_2 * STRIDE;
    float _e7 = rows[metal::min(unsigned(o + 0u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e12 = rows[metal::min(unsigned(o + 1u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e17 = rows[metal::min(unsigned(o + 2u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e22 = rows[metal::min(unsigned(o + 3u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e27 = rows[metal::min(unsigned(o + 4u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e32 = rows[metal::min(unsigned(o + 5u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e37 = rows[metal::min(unsigned(o + 6u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e42 = rows[metal::min(unsigned(o + 7u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e47 = rows[metal::min(unsigned(o + 8u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e56 = rows[metal::min(unsigned(o + 9u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e61 = rows[metal::min(unsigned(o + 10u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e66 = rows[metal::min(unsigned(o + 11u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e73 = rows[metal::min(unsigned(o + 12u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e78 = rows[metal::min(unsigned(o + 13u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e83 = rows[metal::min(unsigned(o + 14u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e88 = rows[metal::min(unsigned(o + 15u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e93 = rows[metal::min(unsigned(o + 16u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e99 = rows[metal::min(unsigned(o + 17u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e104 = rows[metal::min(unsigned(o + 18u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e109 = rows[metal::min(unsigned(o + 19u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e115 = rows[metal::min(unsigned(o + 20u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    return Row {LoftXform {metal::float3x3(metal::float3(_e7, _e12, _e17), metal::float3(_e22, _e27, _e32), metal::float3(_e37, _e42, _e47)), metal::float3(_e56, _e61, _e66)}, _e73, _e78, {}, metal::float3(_e83, _e88, _e93), metal::float3(_e99, _e104, _e109), _e115};
}

LoftXform loft_pose(
    Row r
) {
    return r.r_pose;
}

metal::float4 loft_user_emit_lobe(
    metal::float3 loft_local_color,
    metal::float3 loft_local_n,
    metal::float3 loft_local_v,
    metal::float3 loft_local_l
) {
    return metal::float4(loft_local_color * (1.0 - metal::min(metal::dot(loft_local_l, loft_local_l), 1.0)), 1.0);
}

metal::float3 eval_bsdf(
    Bsdf b,
    metal::float3 n,
    metal::float3 v_1,
    metal::float3 l
) {
    bool local_2 = {};
    metal::float3 c = metal::float3(0.0);
    metal::float3 emission = metal::float3(0.0);
    if (metal::dot(n, l) <= -0.0) {
        local_2 = metal::dot(l, l) > 0.0;
    } else {
        local_2 = false;
    }
    bool _e13 = local_2;
    if (_e13) {
        return metal::float3(0.0);
    }
    metal::float4 _e23 = loft_user_emit_lobe(b.l0_0_, n, v_1, l);
    metal::float3 _e24 = emission;
    emission = _e24 + _e23.xyz;
    metal::float3 _e27 = c;
    metal::float3 _e28 = emission;
    return _e27 + _e28;
}

metal::float3 loft_user_branch_axis(
) {
    return metal::float3(0.0, 0.8660254, 0.5);
}

metal::float3 loft_user_woodblock_pigment(
    Bsdf loft_local_b,
    metal::float3 loft_local_n_1,
    metal::float3 loft_local_v_1,
    metal::float3 loft_local_sun,
    float loft_local_shadow,
    float loft_local_ao
) {
    float loft_local_nl = metal::max(metal::dot(loft_local_n_1, loft_local_sun), 0.0) * loft_local_shadow;
    float loft_local_bands = ((0.25 + (0.27 * metal::smoothstep(0.08, 0.11, loft_local_nl))) + (0.29 * metal::smoothstep(0.41, 0.44, loft_local_nl))) + (0.24 * metal::smoothstep(0.77, 0.8, loft_local_nl));
    metal::float3 _e29 = eval_bsdf(loft_local_b, loft_local_n_1, loft_local_v_1, loft_local_n_1);
    metal::float3 loft_local_pigment = _e29 * 3.1415927;
    float loft_local_wash = (1.0 - metal::smoothstep(0.1, 0.65, loft_local_n_1.y)) * 0.32;
    metal::float3 _e53 = eval_bsdf(loft_local_b, loft_local_n_1, loft_local_v_1, metal::float3(0.0));
    return metal::mix((loft_local_pigment * loft_local_bands) * (0.7 + (0.3 * loft_local_ao)), metal::float3(0.08, 0.12, 0.22), loft_local_wash) + _e53;
}

float q_trace(
    Row loft_local_self,
    metal::float3 loft_local_p
) {
    metal::float3 _e2 = loft_user_branch_axis();
    metal::float3 loft_local_v_2 = loft_local_p - metal::float3(0.0, 0.0, 0.0);
    float loft_local_y = metal::dot(loft_local_v_2, _e2);
    float loft_local_radial = metal::length(loft_local_v_2 - (_e2 * loft_local_y));
    float loft_local_h = metal::clamp(loft_local_y - ((loft_local_radial * loft_const_branch_taper) / metal::sqrt(1.0 - (loft_const_branch_taper * loft_const_branch_taper))), 0.0, loft_local_self.r_len);
    return metal::length(loft_local_v_2 - (_e2 * loft_local_h)) - ((0.171875 * loft_local_self.r_len) - (loft_const_branch_taper * loft_local_h));
}

Bsdf q_material(
    Row loft_local_self_1,
    metal::float3 loft_local_p_1,
    metal::float3 loft_local_n_2
) {
    return Bsdf {metal::mix(metal::float3(0.14, 0.26, 0.44), metal::float3(0.88, 0.32, 0.22), loft_local_self_1.r_level)};
}

float loft_shadow(
    metal::float3 p_1,
    metal::float3 n_1,
    constant Frame& frame,
    metal::depth2d<float, metal::access::sample> shadow_tex,
    metal::sampler shadow_smp
) {
    bool local_3 = {};
    bool local_4 = {};
    bool local_5 = {};
    float s = 0.0;
    uint _e5 = frame.cold.z;
    if (_e5 == 0u) {
        return 1.0;
    }
    metal::float4x4 _e11 = frame.light_vp;
    float _e15 = frame.sun.w;
    metal::float4 q = _e11 * metal::float4(p_1 + (n_1 * (1.5 * _e15)), 1.0);
    metal::float2 uv = metal::float2((q.x * 0.5) + 0.5, 0.5 - (q.y * 0.5));
    if (!(metal::any(uv < metal::float2(0.0)))) {
        local_3 = metal::any(uv > metal::float2(1.0));
    } else {
        local_3 = true;
    }
    bool _e46 = local_3;
    if (!(_e46)) {
        local_4 = q.z > 1.0;
    } else {
        local_4 = true;
    }
    bool _e54 = local_4;
    if (!(_e54)) {
        local_5 = q.z < 0.0;
    } else {
        local_5 = true;
    }
    bool _e62 = local_5;
    if (_e62) {
        return 1.0;
    }
    float texel = 1.0 / static_cast<float>(metal::uint2(shadow_tex.get_width(), shadow_tex.get_height()).x);
    float depth = q.z - 0.0005;
    float _e75 = s;
    float _e83 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(-1.0, -1.0) * texel), depth);
    s = _e75 + _e83;
    float _e85 = s;
    float _e93 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(-1.0, 0.0) * texel), depth);
    s = _e85 + _e93;
    float _e95 = s;
    float _e103 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(-1.0, 1.0) * texel), depth);
    s = _e95 + _e103;
    float _e105 = s;
    float _e113 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(0.0, -1.0) * texel), depth);
    s = _e105 + _e113;
    float _e115 = s;
    float _e123 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(0.0, 0.0) * texel), depth);
    s = _e115 + _e123;
    float _e125 = s;
    float _e133 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(0.0, 1.0) * texel), depth);
    s = _e125 + _e133;
    float _e135 = s;
    float _e143 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(1.0, -1.0) * texel), depth);
    s = _e135 + _e143;
    float _e145 = s;
    float _e153 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(1.0, 0.0) * texel), depth);
    s = _e145 + _e153;
    float _e155 = s;
    float _e163 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(1.0, 1.0) * texel), depth);
    s = _e155 + _e163;
    float _e165 = s;
    return _e165 / 9.0;
}

struct shadeInput {
};
[[max_total_threads_per_threadgroup(64)]] kernel void shade(
  metal::uint3 wg [[threadgroup_position_in_grid]]
, metal::uint3 lid [[thread_position_in_threadgroup]]
, constant Frame& frame [[buffer(0)]]
, device type_8 const& rows [[buffer(3)]]
, constant KindParams& kp [[buffer(4)]]
, metal::texture2d<uint, metal::access::sample> vis_tex [[texture(0)]]
, metal::texture2d<float, metal::access::write> hdr [[texture(1)]]
, device type_9 const& tiles [[buffer(6)]]
, metal::depth2d<float, metal::access::sample> shadow_tex [[texture(2)]]
, metal::sampler shadow_smp [[sampler(0)]]
, constant _mslBufferSizes& _buffer_sizes [[buffer(7)]]
) {
    bool local = {};
    bool local_1 = {};
    metal::float3 g = metal::float3(0.0);
    uint i = 0u;
    float occ = 0.0;
    float w = 1.0;
    uint i_1 = 0u;
    uint _e5 = frame.cold.x;
    if (_e5 == LOFT_NONCE) {
        return;
    }
    uint _e11 = kp.kind_id;
    uint _e15 = frame.size.w;
    uint tile = tiles[metal::min(unsigned((_e11 * _e15) + wg.x), (_buffer_sizes.size5 - 0 - 4) / 4)];
    metal::uint2 px_1 = (metal::uint2(tile & 65535u, tile >> 16u) * 8u) + lid.xy;
    uint _e34 = frame.size.x;
    if (!((px_1.x >= _e34))) {
        uint _e43 = frame.size.y;
        local = px_1.y >= _e43;
    } else {
        local = true;
    }
    bool _e46 = local;
    if (_e46) {
        return;
    }
    uint clamped_lod_e49 = metal::min(uint(0), vis_tex.get_num_mip_levels() - 1);
    metal::uint4 _e49 = vis_tex.read(metal::min(metal::uint2(px_1), metal::uint2(vis_tex.get_width(clamped_lod_e49), vis_tex.get_height(clamped_lod_e49)) - 1), clamped_lod_e49);
    metal::uint2 v_2 = _e49.xy;
    if (!((v_2.x == LOFT_EMPTY))) {
        uint _e62 = kp.kind_id;
        local_1 = (v_2.x >> 24u) != _e62;
    } else {
        local_1 = true;
    }
    bool _e65 = local_1;
    if (_e65) {
        return;
    }
    Row _e69 = load_row(v_2.x & 16777215u, rows, _buffer_sizes);
    metal::float3 _e74 = pf1_contract_off(static_cast<metal::float2>(px_1) + metal::float2(0.5), frame);
    LoftXform _e75 = loft_pose(_e69);
    LoftXform _e76 = loft_xf_inv(_e75);
    float t = as_type<float>(v_2.y);
    metal::float4 _e81 = frame.eye;
    metal::float3 p_2 = _e81.xyz + (_e74 * t);
    metal::float3 _e85 = loft_xf_pt(_e76, p_2);
    float e = 0.0005 * metal::max(1.0, 0.25 * t);
    uint2 loop_bound = uint2(4294967295u);
    bool loop_init = true;
    while(true) {
        if (metal::all(loop_bound == uint2(0u))) { break; }
        loop_bound -= uint2(loop_bound.y == 0u, 1u);
        if (!loop_init) {
            uint _e110 = i;
            i = _e110 + 1u;
        }
        loop_init = false;
        uint _e97 = i;
        if (_e97 < 4u) {
        } else {
            break;
        }
        {
            uint _e101 = i;
            metal::float3 offset = LOFT_TETRA.inner[metal::min(unsigned(_e101), 3u)];
            metal::float3 _e103 = g;
            float _e106 = q_trace(_e69, _e85 + (offset * e));
            g = _e103 + (offset * _e106);
        }
    }
    metal::float3 _e112 = g;
    metal::float3 nl = metal::normalize(_e112);
    uint2 loop_bound_1 = uint2(4294967295u);
    bool loop_init_1 = true;
    while(true) {
        if (metal::all(loop_bound_1 == uint2(0u))) { break; }
        loop_bound_1 -= uint2(loop_bound_1.y == 0u, 1u);
        if (!loop_init_1) {
            uint _e141 = i_1;
            i_1 = _e141 + 1u;
        }
        loop_init_1 = false;
        uint _e120 = i_1;
        if (_e120 < 5u) {
        } else {
            break;
        }
        {
            uint _e123 = i_1;
            float h = 0.02 + (0.06 * static_cast<float>(_e123));
            float _e129 = occ;
            float _e132 = q_trace(_e69, _e85 + (nl * h));
            float _e134 = w;
            occ = _e129 + ((h - _e132) * _e134);
            float _e137 = w;
            w = _e137 * 0.8;
        }
    }
    float _e143 = occ;
    float ao = metal::clamp(1.0 - (2.0 * _e143), 0.0, 1.0);
    metal::float3 _e151 = loft_xf_vec(_e75, nl);
    metal::float3 n_2 = metal::normalize(_e151);
    Bsdf _e153 = q_material(_e69, _e85, nl);
    metal::float4 _e156 = frame.sun;
    metal::float3 sun = metal::normalize(_e156.xyz);
    float _e161 = loft_shadow(p_2, n_2, frame, shadow_tex, shadow_smp);
    metal::float3 _e162 = loft_user_woodblock_pigment(_e153, n_2, -(_e74), sun, _e161, ao);
    hdr.write(metal::float4(_e162, 1.0), metal::uint2(px_1));
    return;
}
