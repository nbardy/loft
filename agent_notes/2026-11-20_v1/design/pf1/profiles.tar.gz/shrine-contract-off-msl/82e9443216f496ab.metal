// language: metal3.2
#include <metal_stdlib>
#include <simd/simd.h>

using metal::uint;

struct _mslBufferSizes {
    uint size0;
    uint size2;
    uint size6;
};

typedef float type_1[1];
struct Frame {
    metal::float4x4 view_proj;
    metal::float4x4 inv_view_proj;
    metal::float4 eye;
    metal::float4 sun;
    metal::uint4 size;
    metal::uint4 cold;
    metal::float4x4 light_vp;
};
struct LoftXform {
    metal::float3x3 r;
    metal::float3 t;
};
struct Row {
    metal::float3 loft_lo;
    metal::packed_float3 loft_hi;
    float loft_lip;
};
struct KindParams {
    uint kind_id;
    uint base;
    uint n_rows;
    uint pad;
};
typedef uint type_9[1];
struct Bsdf {
    metal::packed_float3 l0_0_;
    float l0_1_;
    float l0_2_;
    char _pad3[12];
};
struct type_11 {
    uint inner[36];
};
struct type_13 {
    metal::float3 inner[4];
};
constant uint LOFT_NONCE = 4294967295u;
constant uint LOFT_EMPTY = 4294967295u;
constant uint STRIDE = 7u;
constant type_11 LOFT_CUBE = type_11 {{1u, 3u, 7u, 1u, 7u, 5u, 0u, 6u, 2u, 0u, 4u, 6u, 2u, 6u, 7u, 2u, 7u, 3u, 0u, 1u, 5u, 0u, 5u, 4u, 4u, 5u, 7u, 4u, 7u, 6u, 0u, 2u, 3u, 0u, 3u, 1u}};
constant type_13 LOFT_TETRA = type_13 {{metal::float3(1.0, -1.0, -1.0), metal::float3(-1.0, -1.0, 1.0), metal::float3(-1.0, 1.0, -1.0), metal::float3(1.0, 1.0, 1.0)}};

float loft_ggx_word(
    uint i_2,
    device type_1 const& luts,
    constant _mslBufferSizes& _buffer_sizes
) {
    float _e8 = luts[metal::min(unsigned(((1 + (_buffer_sizes.size0 - 0 - 4) / 4) - 1122u) + i_2), (_buffer_sizes.size0 - 0 - 4) / 4)];
    return _e8;
}

uint naga_f2u32(float value) {
    return static_cast<uint>(metal::clamp(value, 0.0, 4294967000.0));
}

metal::float2 loft_ggx_energy(
    float roughness,
    float mu,
    device type_1 const& luts,
    constant _mslBufferSizes& _buffer_sizes
) {
    float r_1 = metal::clamp(roughness, 0.0, 1.0) * 32.0;
    float v_2 = metal::sqrt(metal::clamp(mu, 0.0, 1.0)) * 32.0;
    uint i_4 = metal::min(naga_f2u32(r_1), 31u);
    uint j = metal::min(naga_f2u32(v_2), 31u);
    uint base = i_4 * 34u;
    float b_1 = v_2 - static_cast<float>(j);
    float _e24 = loft_ggx_word(base + j, luts, _buffer_sizes);
    float _e28 = loft_ggx_word((base + j) + 1u, luts, _buffer_sizes);
    float e0_ = metal::mix(_e24, _e28, b_1);
    float _e33 = loft_ggx_word((base + 34u) + j, luts, _buffer_sizes);
    float _e39 = loft_ggx_word(((base + 34u) + j) + 1u, luts, _buffer_sizes);
    float e1_ = metal::mix(_e33, _e39, b_1);
    float _e43 = loft_ggx_word(base + 33u, luts, _buffer_sizes);
    float _e47 = loft_ggx_word(base + 67u, luts, _buffer_sizes);
    return metal::mix(metal::float2(e0_, _e43), metal::float2(e1_, _e47), r_1 - static_cast<float>(i_4)) / metal::float2(65535.0);
}

metal::float3 loft_xf_pt(
    LoftXform x,
    metal::float3 p
) {
    return (x.r * p) + x.t;
}

metal::float3 loft_xf_vec(
    LoftXform x_1,
    metal::float3 v
) {
    return x_1.r * v;
}

LoftXform loft_xf_inv(
    LoftXform x_2
) {
    metal::float3x3 rt = metal::transpose(x_2.r);
    return LoftXform {rt, -((rt * x_2.t))};
}

metal::float3 loft_ray(
    metal::float2 px,
    constant Frame& frame
) {
    uint _e5 = frame.size.x;
    uint _e16 = frame.size.y;
    metal::float2 ndc = metal::float2(((px.x / static_cast<float>(_e5)) * 2.0) - 1.0, 1.0 - ((px.y / static_cast<float>(_e16)) * 2.0));
    metal::float4x4 _e26 = frame.inv_view_proj;
    metal::float4 far = _e26 * metal::float4(ndc, 1.0, 1.0);
    metal::float4 _e37 = frame.eye;
    return metal::normalize((far.xyz / metal::float3(far.w)) - _e37.xyz);
}

Row load_row(
    uint i_3,
    device type_1 const& rows,
    constant _mslBufferSizes& _buffer_sizes
) {
    uint o = i_3 * STRIDE;
    float _e7 = rows[metal::min(unsigned(o + 0u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    float _e12 = rows[metal::min(unsigned(o + 1u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    float _e17 = rows[metal::min(unsigned(o + 2u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    float _e23 = rows[metal::min(unsigned(o + 3u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    float _e28 = rows[metal::min(unsigned(o + 4u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    float _e33 = rows[metal::min(unsigned(o + 5u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    float _e39 = rows[metal::min(unsigned(o + 6u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    return Row {metal::float3(_e7, _e12, _e17), metal::float3(_e23, _e28, _e33), _e39};
}

LoftXform loft_pose(
    Row r
) {
    return LoftXform {metal::float3x3(metal::float3(1.0, 0.0, 0.0), metal::float3(0.0, 1.0, 0.0), metal::float3(0.0, 0.0, 1.0)), metal::float3(0.0)};
}

float loft_user_pow5_(
    float loft_local_x
) {
    float loft_local_x2_ = loft_local_x * loft_local_x;
    return (loft_local_x2_ * loft_local_x2_) * loft_local_x;
}

metal::float3 loft_user_fresnel(
    metal::float3 loft_local_f0_,
    float loft_local_mu
) {
    float _e10 = loft_user_pow5_(1.0 - metal::clamp(loft_local_mu, 0.0, 1.0));
    return loft_local_f0_ + ((metal::float3(1.0) - loft_local_f0_) * _e10);
}

float loft_user_ggx_dv(
    float loft_local_nh,
    float loft_local_nv,
    float loft_local_nl,
    float loft_local_rough
) {
    float loft_local_a = metal::max(loft_local_rough * loft_local_rough, 0.002);
    float loft_local_a2_ = loft_local_a * loft_local_a;
    float loft_local_q = (1.0 - (loft_local_nh * loft_local_nh)) + ((loft_local_nh * loft_local_nh) * loft_local_a2_);
    float loft_local_gv = loft_local_nl * metal::sqrt(loft_local_a2_ + (((1.0 - loft_local_a2_) * loft_local_nv) * loft_local_nv));
    float loft_local_gl = loft_local_nv * metal::sqrt(loft_local_a2_ + (((1.0 - loft_local_a2_) * loft_local_nl) * loft_local_nl));
    return loft_local_a2_ / (((6.2831855 * loft_local_q) * loft_local_q) * metal::max(loft_local_gv + loft_local_gl, 0.00000001));
}

metal::float3 loft_user_ggx_ms(
    metal::float2 loft_local_eo,
    float loft_local_ei,
    metal::float3 loft_local_favg
) {
    float loft_local_ea = loft_local_eo.y;
    float loft_local_lost = 1.0 - loft_local_ea;
    metal::float3 loft_local_tint = ((loft_local_favg * loft_local_favg) * loft_local_ea) / metal::max(metal::float3(1.0) - (loft_local_favg * loft_local_lost), metal::float3(0.000001));
    return loft_local_tint * ((((1.0 - loft_local_eo.x) * (1.0 - loft_local_ei)) * 0.31830987) / metal::max(loft_local_lost, 0.000001));
}

metal::float3 loft_user_ggx_reflect(
    float loft_local_nh_1,
    float loft_local_nv_1,
    float loft_local_nl_1,
    float loft_local_rough_1,
    metal::float3 loft_local_f_half,
    metal::float3 loft_local_favg_1,
    metal::float2 loft_local_eo_1,
    device type_1 const& luts,
    constant _mslBufferSizes& _buffer_sizes
) {
    metal::float2 _e7 = loft_ggx_energy(loft_local_rough_1, loft_local_nl_1, luts, _buffer_sizes);
    float loft_local_ei_1 = _e7.x;
    float _e9 = loft_user_ggx_dv(loft_local_nh_1, loft_local_nv_1, loft_local_nl_1, loft_local_rough_1);
    metal::float3 _e11 = loft_user_ggx_ms(loft_local_eo_1, loft_local_ei_1, loft_local_favg_1);
    return ((loft_local_f_half * _e9) + _e11) * loft_local_nl_1;
}

metal::float4 loft_user_ggx(
    metal::float3 loft_local_albedo,
    float loft_local_rough_2,
    float loft_local_metal,
    metal::float3 loft_local_n,
    metal::float3 loft_local_v,
    metal::float3 loft_local_l,
    device type_1 const& luts,
    constant _mslBufferSizes& _buffer_sizes
) {
    metal::float3 loft_local_spec = metal::float3(0.0);
    bool local_2 = {};
    float loft_local_nl_2 = metal::max(metal::dot(loft_local_n, loft_local_l), 0.0);
    float loft_local_nv_2 = metal::max(metal::dot(loft_local_n, loft_local_v), 0.0);
    metal::float3 loft_local_f0_1 = metal::mix(metal::float3(0.04), loft_local_albedo, loft_local_metal);
    metal::float3 _e15 = loft_user_fresnel(loft_local_f0_1, loft_local_nv_2);
    metal::float2 _e16 = loft_ggx_energy(loft_local_rough_2, loft_local_nv_2, luts, _buffer_sizes);
    if (loft_local_nl_2 > 0.0) {
        local_2 = loft_local_nv_2 > 0.0;
    } else {
        local_2 = false;
    }
    bool _e27 = local_2;
    if (_e27) {
        metal::float3 loft_local_h = metal::normalize(loft_local_v + loft_local_l);
        metal::float3 _e31 = loft_user_fresnel(loft_local_f0_1, metal::dot(loft_local_v, loft_local_h));
        metal::float3 _e44 = loft_user_ggx_reflect(metal::clamp(metal::dot(loft_local_n, loft_local_h), 0.0, 1.0), loft_local_nv_2, loft_local_nl_2, loft_local_rough_2, _e31, (metal::float3(1.0) + (20.0 * loft_local_f0_1)) / metal::float3(21.0), _e16, luts, _buffer_sizes);
        loft_local_spec = _e44;
    }
    metal::float3 loft_local_diffuse = ((loft_local_albedo * (1.0 - loft_local_metal)) * (metal::float3(1.0) - _e15)) * (0.31830987 * loft_local_nl_2);
    metal::float3 _e55 = loft_local_spec;
    return metal::float4(loft_local_diffuse + _e55, 1.0 - (_e16.x * metal::dot(_e15, metal::float3(0.2126, 0.7152, 0.0722))));
}

metal::float3 eval_bsdf(
    Bsdf b,
    metal::float3 n,
    metal::float3 v_1,
    metal::float3 l,
    device type_1 const& luts,
    constant _mslBufferSizes& _buffer_sizes
) {
    bool local_3 = {};
    metal::float3 c = metal::float3(0.0);
    metal::float3 emission = metal::float3(0.0);
    if (metal::dot(n, l) <= -0.0) {
        local_3 = metal::dot(l, l) > 0.0;
    } else {
        local_3 = false;
    }
    bool _e13 = local_3;
    if (_e13) {
        return metal::float3(0.0);
    }
    metal::float4 _e25 = loft_user_ggx(b.l0_0_, b.l0_1_, b.l0_2_, n, v_1, l, luts, _buffer_sizes);
    metal::float3 _e26 = c;
    c = (_e26 * _e25.w) + _e25.xyz;
    metal::float3 _e31 = c;
    metal::float3 _e32 = emission;
    return _e31 + _e32;
}

float loft_user_box_sdf(
    metal::float3 loft_local_v_1,
    metal::float3 loft_local_half
) {
    metal::float3 loft_local_q_1 = metal::abs(loft_local_v_1.xyz) - loft_local_half;
    return metal::length(metal::max(loft_local_q_1, metal::float3(0.0))) + metal::min(metal::max(loft_local_q_1.x, metal::max(loft_local_q_1.y, loft_local_q_1.z)), 0.0);
}

metal::float3 loft_user_woodblock_pigment(
    Bsdf loft_local_b,
    metal::float3 loft_local_n_1,
    metal::float3 loft_local_v_2,
    metal::float3 loft_local_sun,
    float loft_local_shadow,
    float loft_local_ao,
    device type_1 const& luts,
    constant _mslBufferSizes& _buffer_sizes
) {
    float loft_local_nl_3 = metal::max(metal::dot(loft_local_n_1, loft_local_sun), 0.0) * loft_local_shadow;
    float loft_local_bands = ((0.25 + (0.27 * metal::smoothstep(0.08, 0.11, loft_local_nl_3))) + (0.29 * metal::smoothstep(0.41, 0.44, loft_local_nl_3))) + (0.24 * metal::smoothstep(0.77, 0.8, loft_local_nl_3));
    metal::float3 _e29 = eval_bsdf(loft_local_b, loft_local_n_1, loft_local_v_2, loft_local_n_1, luts, _buffer_sizes);
    metal::float3 loft_local_pigment = _e29 * 3.1415927;
    float loft_local_wash = (1.0 - metal::smoothstep(0.1, 0.65, loft_local_n_1.y)) * 0.32;
    metal::float3 _e53 = eval_bsdf(loft_local_b, loft_local_n_1, loft_local_v_2, metal::float3(0.0), luts, _buffer_sizes);
    return metal::mix((loft_local_pigment * loft_local_bands) * (0.7 + (0.3 * loft_local_ao)), metal::float3(0.08, 0.12, 0.22), loft_local_wash) + _e53;
}

float q_trace(
    Row loft_local_self,
    metal::float3 loft_local_p
) {
    float _e11 = loft_user_box_sdf(loft_local_p - metal::float3(0.0, -0.15, 0.0), metal::float3(5.8, 0.15, 5.8));
    return _e11;
}

Bsdf q_material(
    Row loft_local_self_1,
    metal::float3 loft_local_p_1,
    metal::float3 loft_local_n_2
) {
    return Bsdf {metal::float3(0.32, 0.41, 0.43), 0.72, 0.0};
}

float loft_shadow(
    metal::float3 p_1,
    metal::float3 n_1,
    constant Frame& frame,
    metal::depth2d<float, metal::access::sample> shadow_tex,
    metal::sampler shadow_smp
) {
    bool local_4 = {};
    bool local_5 = {};
    bool local_6 = {};
    float s = 0.0;
    uint _e5 = frame.cold.z;
    if (_e5 == 0u) {
        return 1.0;
    }
    metal::float4x4 _e11 = frame.light_vp;
    float _e15 = frame.sun.w;
    metal::float4 q = _e11 * metal::float4(p_1 + (n_1 * (1.5 * _e15)), 1.0);
    metal::float2 uv = metal::float2((q.x * 0.5) + 0.5, 0.5 - (q.y * 0.5));
    if (!(metal::any(uv < metal::float2(0.0)))) {
        local_4 = metal::any(uv > metal::float2(1.0));
    } else {
        local_4 = true;
    }
    bool _e46 = local_4;
    if (!(_e46)) {
        local_5 = q.z > 1.0;
    } else {
        local_5 = true;
    }
    bool _e54 = local_5;
    if (!(_e54)) {
        local_6 = q.z < 0.0;
    } else {
        local_6 = true;
    }
    bool _e62 = local_6;
    if (_e62) {
        return 1.0;
    }
    float texel = 1.0 / static_cast<float>(metal::uint2(shadow_tex.get_width(), shadow_tex.get_height()).x);
    float depth = q.z - 0.0005;
    float _e75 = s;
    float _e83 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(-1.0, -1.0) * texel), depth);
    s = _e75 + _e83;
    float _e85 = s;
    float _e93 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(-1.0, 0.0) * texel), depth);
    s = _e85 + _e93;
    float _e95 = s;
    float _e103 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(-1.0, 1.0) * texel), depth);
    s = _e95 + _e103;
    float _e105 = s;
    float _e113 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(0.0, -1.0) * texel), depth);
    s = _e105 + _e113;
    float _e115 = s;
    float _e123 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(0.0, 0.0) * texel), depth);
    s = _e115 + _e123;
    float _e125 = s;
    float _e133 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(0.0, 1.0) * texel), depth);
    s = _e125 + _e133;
    float _e135 = s;
    float _e143 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(1.0, -1.0) * texel), depth);
    s = _e135 + _e143;
    float _e145 = s;
    float _e153 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(1.0, 0.0) * texel), depth);
    s = _e145 + _e153;
    float _e155 = s;
    float _e163 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(1.0, 1.0) * texel), depth);
    s = _e155 + _e163;
    float _e165 = s;
    return _e165 / 9.0;
}

struct shadeInput {
};
[[max_total_threads_per_threadgroup(64)]] kernel void shade(
  metal::uint3 wg [[threadgroup_position_in_grid]]
, metal::uint3 lid [[thread_position_in_threadgroup]]
, device type_1 const& luts [[buffer(5)]]
, constant Frame& frame [[buffer(0)]]
, device type_1 const& rows [[buffer(3)]]
, constant KindParams& kp [[buffer(4)]]
, metal::texture2d<uint, metal::access::sample> vis_tex [[texture(0)]]
, metal::texture2d<float, metal::access::write> hdr [[texture(1)]]
, device type_9 const& tiles [[buffer(6)]]
, metal::depth2d<float, metal::access::sample> shadow_tex [[texture(2)]]
, metal::sampler shadow_smp [[sampler(0)]]
, constant _mslBufferSizes& _buffer_sizes [[buffer(7)]]
) {
    bool local = {};
    bool local_1 = {};
    metal::float3 g = metal::float3(0.0);
    uint i = 0u;
    float occ = 0.0;
    float w = 1.0;
    uint i_1 = 0u;
    uint _e5 = frame.cold.x;
    if (_e5 == LOFT_NONCE) {
        return;
    }
    uint _e11 = kp.kind_id;
    uint _e15 = frame.size.w;
    uint tile = tiles[metal::min(unsigned((_e11 * _e15) + wg.x), (_buffer_sizes.size6 - 0 - 4) / 4)];
    metal::uint2 px_1 = (metal::uint2(tile & 65535u, tile >> 16u) * 8u) + lid.xy;
    uint _e34 = frame.size.x;
    if (!((px_1.x >= _e34))) {
        uint _e43 = frame.size.y;
        local = px_1.y >= _e43;
    } else {
        local = true;
    }
    bool _e46 = local;
    if (_e46) {
        return;
    }
    uint clamped_lod_e49 = metal::min(uint(0), vis_tex.get_num_mip_levels() - 1);
    metal::uint4 _e49 = vis_tex.read(metal::min(metal::uint2(px_1), metal::uint2(vis_tex.get_width(clamped_lod_e49), vis_tex.get_height(clamped_lod_e49)) - 1), clamped_lod_e49);
    metal::uint2 v_3 = _e49.xy;
    if (!((v_3.x == LOFT_EMPTY))) {
        uint _e62 = kp.kind_id;
        local_1 = (v_3.x >> 24u) != _e62;
    } else {
        local_1 = true;
    }
    bool _e65 = local_1;
    if (_e65) {
        return;
    }
    Row _e69 = load_row(v_3.x & 16777215u, rows, _buffer_sizes);
    metal::float3 _e74 = loft_ray(static_cast<metal::float2>(px_1) + metal::float2(0.5), frame);
    LoftXform _e75 = loft_pose(_e69);
    LoftXform _e76 = loft_xf_inv(_e75);
    float t = as_type<float>(v_3.y);
    metal::float4 _e81 = frame.eye;
    metal::float3 p_2 = _e81.xyz + (_e74 * t);
    metal::float3 _e85 = loft_xf_pt(_e76, p_2);
    float e = 0.0005 * metal::max(1.0, 0.25 * t);
    uint2 loop_bound = uint2(4294967295u);
    bool loop_init = true;
    while(true) {
        if (metal::all(loop_bound == uint2(0u))) { break; }
        loop_bound -= uint2(loop_bound.y == 0u, 1u);
        if (!loop_init) {
            uint _e110 = i;
            i = _e110 + 1u;
        }
        loop_init = false;
        uint _e97 = i;
        if (_e97 < 4u) {
        } else {
            break;
        }
        {
            uint _e101 = i;
            metal::float3 offset = LOFT_TETRA.inner[metal::min(unsigned(_e101), 3u)];
            metal::float3 _e103 = g;
            float _e106 = q_trace(_e69, _e85 + (offset * e));
            g = _e103 + (offset * _e106);
        }
    }
    metal::float3 _e112 = g;
    metal::float3 nl = metal::normalize(_e112);
    uint2 loop_bound_1 = uint2(4294967295u);
    bool loop_init_1 = true;
    while(true) {
        if (metal::all(loop_bound_1 == uint2(0u))) { break; }
        loop_bound_1 -= uint2(loop_bound_1.y == 0u, 1u);
        if (!loop_init_1) {
            uint _e141 = i_1;
            i_1 = _e141 + 1u;
        }
        loop_init_1 = false;
        uint _e120 = i_1;
        if (_e120 < 5u) {
        } else {
            break;
        }
        {
            uint _e123 = i_1;
            float h = 0.02 + (0.06 * static_cast<float>(_e123));
            float _e129 = occ;
            float _e132 = q_trace(_e69, _e85 + (nl * h));
            float _e134 = w;
            occ = _e129 + ((h - _e132) * _e134);
            float _e137 = w;
            w = _e137 * 0.8;
        }
    }
    float _e143 = occ;
    float ao = metal::clamp(1.0 - (2.0 * _e143), 0.0, 1.0);
    metal::float3 _e151 = loft_xf_vec(_e75, nl);
    metal::float3 n_2 = metal::normalize(_e151);
    Bsdf _e153 = q_material(_e69, _e85, nl);
    metal::float4 _e156 = frame.sun;
    metal::float3 sun = metal::normalize(_e156.xyz);
    float _e161 = loft_shadow(p_2, n_2, frame, shadow_tex, shadow_smp);
    metal::float3 _e162 = loft_user_woodblock_pigment(_e153, n_2, -(_e74), sun, _e161, ao, luts, _buffer_sizes);
    hdr.write(metal::float4(_e162, 1.0), metal::uint2(px_1));
    return;
}
