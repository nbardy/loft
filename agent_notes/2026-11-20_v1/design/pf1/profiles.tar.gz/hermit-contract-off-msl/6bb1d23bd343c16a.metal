// language: metal3.2
#include <metal_stdlib>
#include <simd/simd.h>

using metal::uint;

struct _mslBufferSizes {
    uint size0;
    uint size2;
    uint size3;
    uint size7;
};

typedef float type_1[1];
struct Frame {
    metal::float4x4 view_proj;
    metal::float4x4 inv_view_proj;
    metal::float4 eye;
    metal::float4 sun;
    metal::uint4 size;
    metal::uint4 cold;
    metal::float4x4 light_vp;
};
typedef metal::float4 type_7[1];
struct LoftXform {
    metal::float3x3 r;
    metal::float3 t;
};
struct Row {
    LoftXform r_pose;
    float r_aggro;
    char _pad2[12];
    metal::float3 r_gaze;
    metal::float3 r_tint;
    metal::float3 loft_lo;
    metal::packed_float3 loft_hi;
    float loft_lip;
};
struct KindParams {
    uint kind_id;
    uint base;
    uint n_rows;
    uint pad;
};
typedef uint type_10[1];
struct Bsdf {
    metal::packed_float3 l0_0_;
    float l0_1_;
    float l0_2_;
    char _pad3[12];
    metal::packed_float3 l1_0_;
    float l1_1_;
    float l2_0_;
    float l2_1_;
    char _pad7[8];
};
struct LoftPreparedBsdf {
    float l0_1_;
    char _pad1[12];
    metal::float3 l0_2_;
    metal::float3 l0_3_;
    metal::float2 l0_4_;
    float l1_0_;
    float l2_0_;
    metal::float2 l2_1_;
    float l2_2_;
    char _pad8[4];
};
struct type_13 {
    metal::float3 inner[12];
};
struct type_14 {
    uint inner[36];
};
struct type_16 {
    metal::float3 inner[4];
};
constant uint LOFT_NONCE = 4294967295u;
constant uint LOFT_EMPTY = 4294967295u;
constant uint STRIDE = 26u;
constant type_14 LOFT_CUBE = type_14 {{1u, 3u, 7u, 1u, 7u, 5u, 0u, 6u, 2u, 0u, 4u, 6u, 2u, 6u, 7u, 2u, 7u, 3u, 0u, 1u, 5u, 0u, 5u, 4u, 4u, 5u, 7u, 4u, 7u, 6u, 0u, 2u, 3u, 0u, 3u, 1u}};
constant type_16 LOFT_TETRA = type_16 {{metal::float3(1.0, -1.0, -1.0), metal::float3(-1.0, -1.0, 1.0), metal::float3(-1.0, 1.0, -1.0), metal::float3(1.0, 1.0, 1.0)}};

float loft_ggx_word(
    uint i_1,
    device type_1 const& luts,
    constant _mslBufferSizes& _buffer_sizes
) {
    float _e8 = luts[metal::min(unsigned(((1 + (_buffer_sizes.size0 - 0 - 4) / 4) - 1122u) + i_1), (_buffer_sizes.size0 - 0 - 4) / 4)];
    return _e8;
}

uint naga_f2u32(float value) {
    return static_cast<uint>(metal::clamp(value, 0.0, 4294967000.0));
}

metal::float2 loft_ggx_energy(
    float roughness,
    float mu,
    device type_1 const& luts,
    constant _mslBufferSizes& _buffer_sizes
) {
    float r_1 = metal::clamp(roughness, 0.0, 1.0) * 32.0;
    float v_3 = metal::sqrt(metal::clamp(mu, 0.0, 1.0)) * 32.0;
    uint i_4 = metal::min(naga_f2u32(r_1), 31u);
    uint j = metal::min(naga_f2u32(v_3), 31u);
    uint base = i_4 * 34u;
    float b_2 = v_3 - static_cast<float>(j);
    float _e24 = loft_ggx_word(base + j, luts, _buffer_sizes);
    float _e28 = loft_ggx_word((base + j) + 1u, luts, _buffer_sizes);
    float e0_ = metal::mix(_e24, _e28, b_2);
    float _e33 = loft_ggx_word((base + 34u) + j, luts, _buffer_sizes);
    float _e39 = loft_ggx_word(((base + 34u) + j) + 1u, luts, _buffer_sizes);
    float e1_ = metal::mix(_e33, _e39, b_2);
    float _e43 = loft_ggx_word(base + 33u, luts, _buffer_sizes);
    float _e47 = loft_ggx_word(base + 67u, luts, _buffer_sizes);
    return metal::mix(metal::float2(e0_, _e43), metal::float2(e1_, _e47), r_1 - static_cast<float>(i_4)) / metal::float2(65535.0);
}

metal::float3 loft_xf_pt(
    LoftXform x,
    metal::float3 p
) {
    return (x.r * p) + x.t;
}

metal::float3 loft_xf_vec(
    LoftXform x_1,
    metal::float3 v
) {
    return x_1.r * v;
}

LoftXform loft_xf_inv(
    LoftXform x_2
) {
    metal::float3x3 rt = metal::transpose(x_2.r);
    return LoftXform {rt, -((rt * x_2.t))};
}

metal::float3 loft_rot_z(
    metal::float3 p_1,
    float a
) {
    float s_1 = metal::sin(a);
    float c_2 = metal::cos(a);
    return metal::float3((c_2 * p_1.x) + (s_1 * p_1.y), (c_2 * p_1.y) - (s_1 * p_1.x), p_1.z);
}

metal::float3 loft_ray(
    metal::float2 px,
    constant Frame& frame
) {
    uint _e5 = frame.size.x;
    uint _e16 = frame.size.y;
    metal::float2 ndc = metal::float2(((px.x / static_cast<float>(_e5)) * 2.0) - 1.0, 1.0 - ((px.y / static_cast<float>(_e16)) * 2.0));
    metal::float4x4 _e26 = frame.inv_view_proj;
    metal::float4 far = _e26 * metal::float4(ndc, 1.0, 1.0);
    metal::float4 _e37 = frame.eye;
    return metal::normalize((far.xyz / metal::float3(far.w)) - _e37.xyz);
}

Row load_row(
    uint i_2,
    device type_1 const& rows,
    constant _mslBufferSizes& _buffer_sizes
) {
    uint o = i_2 * STRIDE;
    float _e7 = rows[metal::min(unsigned(o + 0u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e12 = rows[metal::min(unsigned(o + 1u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e17 = rows[metal::min(unsigned(o + 2u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e22 = rows[metal::min(unsigned(o + 3u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e27 = rows[metal::min(unsigned(o + 4u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e32 = rows[metal::min(unsigned(o + 5u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e37 = rows[metal::min(unsigned(o + 6u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e42 = rows[metal::min(unsigned(o + 7u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e47 = rows[metal::min(unsigned(o + 8u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e56 = rows[metal::min(unsigned(o + 9u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e61 = rows[metal::min(unsigned(o + 10u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e66 = rows[metal::min(unsigned(o + 11u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e73 = rows[metal::min(unsigned(o + 12u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e78 = rows[metal::min(unsigned(o + 13u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e83 = rows[metal::min(unsigned(o + 14u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e88 = rows[metal::min(unsigned(o + 15u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e94 = rows[metal::min(unsigned(o + 16u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e99 = rows[metal::min(unsigned(o + 17u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e104 = rows[metal::min(unsigned(o + 18u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e110 = rows[metal::min(unsigned(o + 19u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e115 = rows[metal::min(unsigned(o + 20u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e120 = rows[metal::min(unsigned(o + 21u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e126 = rows[metal::min(unsigned(o + 22u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e131 = rows[metal::min(unsigned(o + 23u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e136 = rows[metal::min(unsigned(o + 24u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e142 = rows[metal::min(unsigned(o + 25u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    return Row {LoftXform {metal::float3x3(metal::float3(_e7, _e12, _e17), metal::float3(_e22, _e27, _e32), metal::float3(_e37, _e42, _e47)), metal::float3(_e56, _e61, _e66)}, _e73, {}, metal::float3(_e78, _e83, _e88), metal::float3(_e94, _e99, _e104), metal::float3(_e110, _e115, _e120), metal::float3(_e126, _e131, _e136), _e142};
}

LoftXform loft_pose(
    Row r
) {
    return r.r_pose;
}

float loft_user_pow5_(
    float loft_local_x
) {
    float loft_local_x2_ = loft_local_x * loft_local_x;
    return (loft_local_x2_ * loft_local_x2_) * loft_local_x;
}

metal::float3 loft_user_fresnel(
    metal::float3 loft_local_f0_,
    float loft_local_mu
) {
    float _e10 = loft_user_pow5_(1.0 - metal::clamp(loft_local_mu, 0.0, 1.0));
    return loft_local_f0_ + ((metal::float3(1.0) - loft_local_f0_) * _e10);
}

float loft_user_ggx_dv(
    float loft_local_nh,
    float loft_local_nv,
    float loft_local_nl,
    float loft_local_rough
) {
    float loft_local_a_2 = metal::max(loft_local_rough * loft_local_rough, 0.002);
    float loft_local_a2_ = loft_local_a_2 * loft_local_a_2;
    float loft_local_q_2 = (1.0 - (loft_local_nh * loft_local_nh)) + ((loft_local_nh * loft_local_nh) * loft_local_a2_);
    float loft_local_gv = loft_local_nl * metal::sqrt(loft_local_a2_ + (((1.0 - loft_local_a2_) * loft_local_nv) * loft_local_nv));
    float loft_local_gl = loft_local_nv * metal::sqrt(loft_local_a2_ + (((1.0 - loft_local_a2_) * loft_local_nl) * loft_local_nl));
    return loft_local_a2_ / (((6.2831855 * loft_local_q_2) * loft_local_q_2) * metal::max(loft_local_gv + loft_local_gl, 0.00000001));
}

metal::float3 loft_user_ggx_ms(
    metal::float2 loft_local_eo,
    float loft_local_ei,
    metal::float3 loft_local_favg
) {
    float loft_local_ea = loft_local_eo.y;
    float loft_local_lost = 1.0 - loft_local_ea;
    metal::float3 loft_local_tint = ((loft_local_favg * loft_local_favg) * loft_local_ea) / metal::max(metal::float3(1.0) - (loft_local_favg * loft_local_lost), metal::float3(0.000001));
    return loft_local_tint * ((((1.0 - loft_local_eo.x) * (1.0 - loft_local_ei)) * 0.31830987) / metal::max(loft_local_lost, 0.000001));
}

metal::float3 loft_user_ggx_reflect(
    float loft_local_nh_1,
    float loft_local_nv_1,
    float loft_local_nl_1,
    float loft_local_rough_1,
    metal::float3 loft_local_f_half,
    metal::float3 loft_local_favg_1,
    metal::float2 loft_local_eo_1,
    device type_1 const& luts,
    constant _mslBufferSizes& _buffer_sizes
) {
    metal::float2 _e7 = loft_ggx_energy(loft_local_rough_1, loft_local_nl_1, luts, _buffer_sizes);
    float loft_local_ei_1 = _e7.x;
    float _e9 = loft_user_ggx_dv(loft_local_nh_1, loft_local_nv_1, loft_local_nl_1, loft_local_rough_1);
    metal::float3 _e11 = loft_user_ggx_ms(loft_local_eo_1, loft_local_ei_1, loft_local_favg_1);
    return ((loft_local_f_half * _e9) + _e11) * loft_local_nl_1;
}

LoftPreparedBsdf loft_prepare_bsdf(
    Bsdf b,
    metal::float3 n,
    metal::float3 v_1,
    device type_1 const& luts,
    constant _mslBufferSizes& _buffer_sizes
) {
    LoftPreparedBsdf c = {};
    {
        metal::float3 loft_local_albedo_1 = b.l0_0_;
        float loft_local_rough_4 = b.l0_1_;
        float loft_local_metal_1 = b.l0_2_;
        float loft_local_nv_2 = metal::max(metal::dot(n, v_1), 0.0);
        c.l0_1_ = loft_local_nv_2;
        metal::float3 loft_local_f0_1 = metal::mix(metal::float3(0.04), loft_local_albedo_1, loft_local_metal_1);
        c.l0_2_ = loft_local_f0_1;
        metal::float3 _e15 = loft_user_fresnel(loft_local_f0_1, loft_local_nv_2);
        c.l0_3_ = _e15;
        metal::float2 _e17 = loft_ggx_energy(loft_local_rough_4, loft_local_nv_2, luts, _buffer_sizes);
        c.l0_4_ = _e17;
    }
    {
        metal::float3 loft_local_color_1 = b.l1_0_;
        float loft_local_radius_1 = b.l1_1_;
        float loft_local_w = metal::clamp(loft_local_radius_1 * 4.0, 0.0, 1.0);
        c.l1_0_ = loft_local_w;
    }
    {
        float loft_local_weight_1 = b.l2_0_;
        float loft_local_rough_5 = b.l2_1_;
        float loft_local_nv_3 = metal::max(metal::dot(n, v_1), 0.0);
        c.l2_0_ = loft_local_nv_3;
        metal::float2 _e33 = loft_ggx_energy(loft_local_rough_5, loft_local_nv_3, luts, _buffer_sizes);
        c.l2_1_ = _e33;
        metal::float3 _e37 = loft_user_fresnel(metal::float3(0.04), loft_local_nv_3);
        float loft_local_fv = _e37.x;
        c.l2_2_ = loft_local_fv;
    }
    LoftPreparedBsdf _e40 = c;
    return _e40;
}

metal::float4 loft_prepared_lobe_0_(
    metal::float3 loft_local_albedo,
    float loft_local_rough_2,
    float loft_local_metal,
    metal::float3 loft_local_n,
    metal::float3 loft_local_v,
    metal::float3 loft_local_l,
    LoftPreparedBsdf prepared,
    device type_1 const& luts,
    constant _mslBufferSizes& _buffer_sizes
) {
    metal::float3 loft_local_spec = metal::float3(0.0);
    bool local_2 = {};
    float loft_local_nl_2 = metal::max(metal::dot(loft_local_n, loft_local_l), 0.0);
    float loft_local_nv_4 = prepared.l0_1_;
    metal::float3 loft_local_f0_2 = prepared.l0_2_;
    metal::float3 loft_local_fv_1 = prepared.l0_3_;
    metal::float2 loft_local_eo_2 = prepared.l0_4_;
    if (loft_local_nl_2 > 0.0) {
        local_2 = loft_local_nv_4 > 0.0;
    } else {
        local_2 = false;
    }
    bool _e24 = local_2;
    if (_e24) {
        metal::float3 loft_local_h_1 = metal::normalize(loft_local_v + loft_local_l);
        metal::float3 _e28 = loft_user_fresnel(loft_local_f0_2, metal::dot(loft_local_v, loft_local_h_1));
        metal::float3 _e41 = loft_user_ggx_reflect(metal::clamp(metal::dot(loft_local_n, loft_local_h_1), 0.0, 1.0), loft_local_nv_4, loft_local_nl_2, loft_local_rough_2, _e28, (metal::float3(1.0) + (20.0 * loft_local_f0_2)) / metal::float3(21.0), loft_local_eo_2, luts, _buffer_sizes);
        loft_local_spec = _e41;
    }
    metal::float3 loft_local_diffuse = ((loft_local_albedo * (1.0 - loft_local_metal)) * (metal::float3(1.0) - loft_local_fv_1)) * (0.31830987 * loft_local_nl_2);
    metal::float3 _e52 = loft_local_spec;
    return metal::float4(loft_local_diffuse + _e52, 1.0 - (prepared.l0_4_.x * metal::dot(loft_local_fv_1, metal::float3(0.2126, 0.7152, 0.0722))));
}

metal::float4 loft_prepared_lobe_1_(
    metal::float3 loft_local_color,
    float loft_local_radius,
    metal::float3 loft_local_n_1,
    metal::float3 loft_local_v_1,
    metal::float3 loft_local_l_1,
    LoftPreparedBsdf prepared_1
) {
    float loft_local_w_1 = prepared_1.l1_0_;
    float loft_local_lit = metal::min(metal::dot(loft_local_l_1, loft_local_l_1), 1.0);
    float loft_local_wrap = metal::max(metal::dot(loft_local_n_1, loft_local_l_1) + loft_local_w_1, 0.0) / ((1.0 + loft_local_w_1) * (1.0 + loft_local_w_1));
    return metal::float4(loft_local_color * (((0.31830987 * loft_local_wrap) * loft_local_lit) * loft_local_w_1), 1.0);
}

metal::float4 loft_prepared_lobe_2_(
    float loft_local_weight,
    float loft_local_rough_3,
    metal::float3 loft_local_n_2,
    metal::float3 loft_local_v_2,
    metal::float3 loft_local_l_2,
    LoftPreparedBsdf prepared_2,
    device type_1 const& luts,
    constant _mslBufferSizes& _buffer_sizes
) {
    metal::float3 loft_local_spec_1 = metal::float3(0.0);
    bool local_3 = {};
    float loft_local_nv_5 = prepared_2.l2_0_;
    metal::float2 loft_local_eo_3 = prepared_2.l2_1_;
    float loft_local_fv_2 = prepared_2.l2_2_;
    float loft_local_nl_3 = metal::dot(loft_local_n_2, loft_local_l_2);
    if (loft_local_nl_3 > 0.0) {
        local_3 = loft_local_nv_5 > 0.0;
    } else {
        local_3 = false;
    }
    bool _e20 = local_3;
    if (_e20) {
        metal::float3 loft_local_h_2 = metal::normalize(loft_local_v_2 + loft_local_l_2);
        metal::float3 _e26 = loft_user_fresnel(metal::float3(0.04), metal::dot(loft_local_v_2, loft_local_h_2));
        metal::float3 _e33 = loft_user_ggx_reflect(metal::clamp(metal::dot(loft_local_n_2, loft_local_h_2), 0.0, 1.0), loft_local_nv_5, loft_local_nl_3, loft_local_rough_3, _e26, metal::float3(0.08571429), loft_local_eo_3, luts, _buffer_sizes);
        loft_local_spec_1 = _e33;
    }
    metal::float3 _e34 = loft_local_spec_1;
    return metal::float4(loft_local_weight * _e34, 1.0 - ((loft_local_weight * prepared_2.l2_1_.x) * loft_local_fv_2));
}

metal::float3 loft_eval_prepared(
    Bsdf b_1,
    metal::float3 n_1,
    metal::float3 v_2,
    metal::float3 l,
    LoftPreparedBsdf prepared_3,
    device type_1 const& luts,
    constant _mslBufferSizes& _buffer_sizes
) {
    bool local_4 = {};
    metal::float3 c_1 = metal::float3(0.0);
    metal::float3 emission = metal::float3(0.0);
    if (metal::dot(n_1, l) <= -(metal::max(0.0, metal::clamp(b_1.l1_1_ * 4.0, 0.0, 1.0)))) {
        local_4 = metal::dot(l, l) > 0.0;
    } else {
        local_4 = false;
    }
    bool _e22 = local_4;
    if (_e22) {
        return metal::float3(0.0);
    }
    metal::float4 _e34 = loft_prepared_lobe_0_(b_1.l0_0_, b_1.l0_1_, b_1.l0_2_, n_1, v_2, l, prepared_3, luts, _buffer_sizes);
    metal::float3 _e35 = c_1;
    c_1 = (_e35 * _e34.w) + _e34.xyz;
    metal::float4 _e42 = loft_prepared_lobe_1_(b_1.l1_0_, b_1.l1_1_, n_1, v_2, l, prepared_3);
    metal::float3 _e43 = c_1;
    c_1 = (_e43 * _e42.w) + _e42.xyz;
    metal::float4 _e50 = loft_prepared_lobe_2_(b_1.l2_0_, b_1.l2_1_, n_1, v_2, l, prepared_3, luts, _buffer_sizes);
    metal::float3 _e51 = c_1;
    c_1 = (_e51 * _e50.w) + _e50.xyz;
    metal::float3 _e56 = c_1;
    metal::float3 _e57 = emission;
    return _e56 + _e57;
}

float loft_user_box_sdf(
    metal::float3 loft_local_v_3,
    metal::float3 loft_local_half
) {
    metal::float3 loft_local_q_3 = metal::abs(loft_local_v_3.xyz) - loft_local_half;
    return metal::length(metal::max(loft_local_q_3, metal::float3(0.0))) + metal::min(metal::max(loft_local_q_3.x, metal::max(loft_local_q_3.y, loft_local_q_3.z)), 0.0);
}

float loft_user_smin(
    float loft_local_a,
    float loft_local_b,
    float loft_local_k
) {
    float loft_local_h_3 = metal::max(loft_local_k - metal::abs(loft_local_a - loft_local_b), 0.0) / loft_local_k;
    return metal::min(loft_local_a, loft_local_b) - (((loft_local_h_3 * loft_local_h_3) * loft_local_k) * 0.25);
}

float loft_user_sphere(
    metal::float3 loft_local_v_4,
    float loft_local_r
) {
    return metal::length(loft_local_v_4) - loft_local_r;
}

float loft_user_capsule(
    metal::float3 loft_local_p,
    metal::float3 loft_local_a_1,
    metal::float3 loft_local_b_1,
    float loft_local_r_1
) {
    metal::float3 loft_local_pa = loft_local_p - loft_local_a_1;
    metal::float3 loft_local_ba = loft_local_b_1 - loft_local_a_1;
    float loft_local_h_4 = metal::clamp(metal::dot(loft_local_pa, loft_local_ba) / metal::max(metal::dot(loft_local_ba, loft_local_ba), 0.000000000001), 0.0, 1.0);
    return metal::length(loft_local_pa - (loft_local_ba * loft_local_h_4)) - loft_local_r_1;
}

float loft_user_round_box(
    metal::float3 loft_local_v_5,
    metal::float3 loft_local_half_1,
    float loft_local_r_2
) {
    float _e5 = loft_user_box_sdf(loft_local_v_5, loft_local_half_1 - metal::float3(loft_local_r_2));
    return _e5 - loft_local_r_2;
}

float loft_user_hash3_(
    int loft_local_x_1,
    int loft_local_y,
    int loft_local_z
) {
    uint loft_local_h = {};
    loft_local_h = ((static_cast<uint>(loft_local_x_1) * 73856093u) ^ (static_cast<uint>(loft_local_y) * 19349663u)) ^ (static_cast<uint>(loft_local_z) * 83492791u);
    uint _e15 = loft_local_h;
    uint _e16 = loft_local_h;
    loft_local_h = (_e15 ^ (_e16 >> 13u)) * 1274126177u;
    uint _e22 = loft_local_h;
    uint _e23 = loft_local_h;
    loft_local_h = _e22 ^ (_e23 >> 16u);
    uint _e27 = loft_local_h;
    return static_cast<float>(_e27 & 16777215u) / 16777216.0;
}

int naga_f2i32(float value) {
    return static_cast<int>(metal::clamp(value, -2147483600.0, 2147483500.0));
}

float loft_user_vnoise(
    metal::float3 loft_local_p_1
) {
    metal::float3 loft_local_i_2 = metal::floor(loft_local_p_1);
    metal::float3 loft_local_f = loft_local_p_1 - loft_local_i_2;
    metal::float3 loft_local_u = (loft_local_f * loft_local_f) * (metal::float3(3.0) - (2.0 * loft_local_f));
    int loft_local_x_2 = naga_f2i32(loft_local_i_2.x);
    int loft_local_y_1 = naga_f2i32(loft_local_i_2.y);
    int loft_local_z_1 = naga_f2i32(loft_local_i_2.z);
    float _e16 = loft_user_hash3_(loft_local_x_2, loft_local_y_1, loft_local_z_1);
    float _e19 = loft_user_hash3_(as_type<int>(as_type<uint>(loft_local_x_2) + as_type<uint>(1)), loft_local_y_1, loft_local_z_1);
    float _e24 = loft_user_hash3_(loft_local_x_2, as_type<int>(as_type<uint>(loft_local_y_1) + as_type<uint>(1)), loft_local_z_1);
    float _e29 = loft_user_hash3_(as_type<int>(as_type<uint>(loft_local_x_2) + as_type<uint>(1)), as_type<int>(as_type<uint>(loft_local_y_1) + as_type<uint>(1)), loft_local_z_1);
    float loft_local_a_3 = metal::mix(metal::mix(_e16, _e19, loft_local_u.x), metal::mix(_e24, _e29, loft_local_u.x), loft_local_u.y);
    float _e36 = loft_user_hash3_(loft_local_x_2, loft_local_y_1, as_type<int>(as_type<uint>(loft_local_z_1) + as_type<uint>(1)));
    float _e41 = loft_user_hash3_(as_type<int>(as_type<uint>(loft_local_x_2) + as_type<uint>(1)), loft_local_y_1, as_type<int>(as_type<uint>(loft_local_z_1) + as_type<uint>(1)));
    float _e48 = loft_user_hash3_(loft_local_x_2, as_type<int>(as_type<uint>(loft_local_y_1) + as_type<uint>(1)), as_type<int>(as_type<uint>(loft_local_z_1) + as_type<uint>(1)));
    float _e55 = loft_user_hash3_(as_type<int>(as_type<uint>(loft_local_x_2) + as_type<uint>(1)), as_type<int>(as_type<uint>(loft_local_y_1) + as_type<uint>(1)), as_type<int>(as_type<uint>(loft_local_z_1) + as_type<uint>(1)));
    float loft_local_b_3 = metal::mix(metal::mix(_e36, _e41, loft_local_u.x), metal::mix(_e48, _e55, loft_local_u.x), loft_local_u.y);
    return metal::mix(loft_local_a_3, loft_local_b_3, loft_local_u.z);
}

float loft_user_fbm2_(
    metal::float3 loft_local_p_2
) {
    float _e1 = loft_user_vnoise(loft_local_p_2);
    float _e11 = loft_user_vnoise((loft_local_p_2 * 2.03) + metal::float3(1.7, 9.2, 3.1));
    return (0.667 * _e1) + (0.333 * _e11);
}

metal::float3 loft_internal_raw_6_776_(
    uint i_3
) {
    return type_13 {{metal::float3(0.3996526, 0.9166667, 0.0), metal::float3(-0.48772362, 0.75, 0.44679487), metal::float3(0.0710099, 0.5833334, -0.80912286), metal::float3(0.5531074, 0.4166667, 0.7214298), metal::float3(-0.95344484, 0.25, -0.16865061), metal::float3(0.84082043, 0.08333331, -0.5348613), metal::float3(-0.25870034, -0.08333337, 0.9623563), metal::float3(-0.44627205, -0.25, -0.8592679), metal::float3(0.85389906, -0.41666663, 0.31184188), metal::float3(-0.7507836, -0.5833334, 0.30991307), metal::float3(0.28034753, -0.75, -0.599087), metal::float3(0.119609706, -0.9166666, 0.38133422)}}.inner[metal::min(unsigned(i_3), 11u)];
}

metal::float3 loft_user_sky_dome(
    metal::float3 loft_local_d,
    device type_7 const& loft_params,
    constant _mslBufferSizes& _buffer_sizes
) {
    bool local_5 = {};
    float loft_local_up = metal::clamp(loft_local_d.y, -1.0, 1.0);
    metal::float4 _e7 = loft_params[metal::min(unsigned(2), (_buffer_sizes.size2 - 0 - 16) / 16)];
    metal::float4 _e11 = loft_params[metal::min(unsigned(1), (_buffer_sizes.size2 - 0 - 16) / 16)];
    metal::float3 loft_local_sky = metal::mix(_e7.xyz, _e11.xyz, metal::sqrt(metal::max(loft_local_up, 0.0)));
    metal::float3 loft_local_ground = metal::mix(metal::float3(0.24, 0.21, 0.16), metal::float3(0.12, 0.1, 0.08), metal::sqrt(metal::max(-(loft_local_up), 0.0)));
    if (!((loft_local_up >= 0.0))) {
        float _e38 = loft_params[metal::min(unsigned(1), (_buffer_sizes.size2 - 0 - 16) / 16)].w;
        local_5 = _e38 != 0.0;
    } else {
        local_5 = true;
    }
    bool _e42 = local_5;
    return _e42 ? loft_local_sky : loft_local_ground;
}

metal::float3 loft_user_sky_patch(
    uint loft_local_i
) {
    metal::float3 _e1 = loft_internal_raw_6_776_(loft_local_i);
    return _e1;
}

metal::float3 loft_user_sun_sky(
    Bsdf loft_local_b_2,
    metal::float3 loft_local_n_3,
    metal::float3 loft_local_v_6,
    metal::float3 loft_local_sun,
    float loft_local_shadow,
    float loft_local_ao,
    device type_1 const& luts,
    device type_7 const& loft_params,
    constant _mslBufferSizes& _buffer_sizes
) {
    metal::float3 loft_local_c = metal::float3(0.0);
    uint loft_local_i_1 = 0u;
    metal::float3 loft_local_l_3 = {};
    metal::float3 loft_local_e = {};
    LoftPreparedBsdf _e6 = loft_prepare_bsdf(loft_local_b_2, loft_local_n_3, loft_local_v_6, luts, _buffer_sizes);
    uint2 loop_bound = uint2(4294967295u);
    bool loop_init = true;
    while(true) {
        if (metal::all(loop_bound == uint2(0u))) { break; }
        loop_bound -= uint2(loop_bound.y == 0u, 1u);
        if (!loop_init) {
            uint _e49 = loft_local_i_1;
            loft_local_i_1 = _e49 + 1u;
        }
        loop_init = false;
        uint _e12 = loft_local_i_1;
        if (_e12 < 14u) {
        } else {
            break;
        }
        {
            loft_local_l_3 = metal::float3(0.0);
            loft_local_e = metal::float3(1.0);
            uint _e21 = loft_local_i_1;
            if (_e21 == 1u) {
                loft_local_l_3 = loft_local_sun;
                metal::float4 _e26 = loft_params[metal::min(unsigned(0), (_buffer_sizes.size2 - 0 - 16) / 16)];
                loft_local_e = _e26.xyz * loft_local_shadow;
            }
            uint _e29 = loft_local_i_1;
            if (_e29 >= 2u) {
                uint _e32 = loft_local_i_1;
                metal::float3 _e36 = loft_user_sky_patch(static_cast<uint>(_e32 - 2u));
                loft_local_l_3 = _e36;
                metal::float3 _e37 = loft_local_l_3;
                metal::float3 _e38 = loft_user_sky_dome(_e37, loft_params, _buffer_sizes);
                loft_local_e = _e38 * (0.89011794 * loft_local_ao);
            }
            metal::float3 _e42 = loft_local_c;
            metal::float3 _e43 = loft_local_l_3;
            metal::float3 _e44 = loft_eval_prepared(loft_local_b_2, loft_local_n_3, loft_local_v_6, _e43, _e6, luts, _buffer_sizes);
            metal::float3 _e45 = loft_local_e;
            loft_local_c = _e42 + (_e44 * _e45);
        }
    }
    metal::float3 _e51 = loft_local_c;
    return _e51;
}

float q_trace(
    Row loft_local_self,
    metal::float3 loft_local_q
) {
    float loft_map_3_sym_cell = (loft_local_q.x >= 0.0) ? 1.0 : -1.0;
    metal::float3 loft_map_3_sym_s1_ = metal::float3(metal::abs(loft_local_q.x), loft_local_q.yz);
    metal::float3 loft_map_3_sym_t1_ = metal::float3(-0.15, -0.72, -0.42);
    metal::float3 loft_map_4_brow_s0_ = loft_map_3_sym_s1_ + loft_map_3_sym_t1_;
    float _e27 = loft_user_round_box(loft_local_q - metal::float3(0.0, 0.58, 0.12), metal::float3(0.4, 0.18, 0.34), 0.15);
    float _e37 = loft_user_capsule(loft_local_q, metal::float3(-0.22, 0.52, 0.44), metal::float3(0.22, 0.52, 0.44), 0.09);
    metal::float3 loft_local_eye_c = metal::float3(0.03, 0.3, 0.07);
    float _e47 = loft_user_capsule(loft_map_4_brow_s0_, metal::float3(0.0, 0.0, 0.0), loft_local_eye_c, 0.045);
    float _e50 = loft_user_sphere(loft_map_4_brow_s0_ - loft_local_eye_c, 0.085);
    metal::float3 loft_map_4_brow_t0_ = metal::float3(-0.0, -0.4, -0.02);
    metal::float3 loft_map_4_brow_s1_ = loft_map_4_brow_s0_ + loft_map_4_brow_t0_;
    float loft_map_4_brow_a1_ = -0.35 * loft_local_self.r_aggro;
    metal::float3 _e59 = loft_rot_z(loft_map_4_brow_s1_, loft_map_4_brow_a1_);
    float _e70 = loft_user_round_box(_e59 - metal::float3(0.0, 0.0, 0.0), metal::float3(0.11, 0.025, 0.07), 0.02);
    float _e80 = loft_user_capsule(loft_map_4_brow_s0_, metal::float3(-0.05, 0.02, 0.06), metal::float3(0.32, 0.55, 0.95), 0.016);
    float _e82 = loft_user_smin(_e47, _e50, 0.03);
    float _e84 = loft_user_smin(_e82, _e70, 0.02);
    float _e86 = loft_user_smin(_e27, _e37, 0.08);
    float _e88 = loft_user_smin(_e86, _e84, 0.05);
    return metal::min(_e88, _e80);
}

Bsdf q_material(
    Row loft_local_self_1,
    metal::float3 loft_local_q_1,
    metal::float3 loft_local_n_4
) {
    float loft_map_3_sym_cell_1 = (loft_local_q_1.x >= 0.0) ? 1.0 : -1.0;
    metal::float3 loft_map_3_sym_s1_1 = metal::float3(metal::abs(loft_local_q_1.x), loft_local_q_1.yz);
    metal::float3 loft_map_3_sym_t1_1 = metal::float3(-0.15, -0.72, -0.42);
    metal::float3 loft_local_sym = loft_map_3_sym_s1_1 + loft_map_3_sym_t1_1;
    metal::float3 loft_local_eye_c_1 = metal::float3(0.03, 0.3, 0.07);
    LoftXform _e23 = loft_xf_inv(loft_local_self_1.r_pose);
    metal::float3 _e31 = loft_xf_pt(loft_local_self_1.r_pose, (loft_local_eye_c_1 - loft_map_3_sym_t1_1) * metal::float3(loft_map_3_sym_cell_1, 1.0, 1.0));
    metal::float3 _e34 = loft_xf_vec(_e23, metal::normalize(loft_local_self_1.r_gaze - _e31));
    metal::float3 loft_local_look = _e34 * metal::float3(loft_map_3_sym_cell_1, 1.0, 1.0);
    float loft_local_in_eye = 1.0 - metal::smoothstep(0.088, 0.095, metal::distance(loft_local_sym, loft_local_eye_c_1));
    float loft_local_pupil = metal::smoothstep(0.8, 0.9, metal::dot(metal::normalize(loft_local_sym - loft_local_eye_c_1), loft_local_look)) * loft_local_in_eye;
    float _e70 = loft_user_fbm2_(loft_local_q_1.xyz * 11.0);
    metal::float3 loft_local_skin = (metal::mix(metal::float3(0.55, 0.12, 0.05), metal::float3(0.85, 0.42, 0.18), metal::smoothstep(0.45, 0.8, loft_local_q_1.y)) * loft_local_self_1.r_tint) * (0.75 + (0.5 * _e70));
    metal::float3 loft_local_iris = metal::mix(metal::float3(0.85, 0.62, 0.15), metal::float3(0.01, 0.01, 0.012), loft_local_pupil);
    return Bsdf {metal::mix(loft_local_skin, loft_local_iris, loft_local_in_eye), metal::mix(0.5, 0.2, loft_local_in_eye), 0.0, {}, metal::float3(0.9, 0.35, 0.15), 0.12 * (1.0 - loft_local_in_eye), 0.35 + (0.65 * loft_local_in_eye), 0.05};
}

float loft_shadow(
    metal::float3 p_2,
    metal::float3 n_2,
    constant Frame& frame,
    metal::depth2d<float, metal::access::sample> shadow_tex,
    metal::sampler shadow_smp
) {
    bool local_6 = {};
    bool local_7 = {};
    bool local_8 = {};
    float s = 0.0;
    uint _e5 = frame.cold.z;
    if (_e5 == 0u) {
        return 1.0;
    }
    metal::float4x4 _e11 = frame.light_vp;
    float _e15 = frame.sun.w;
    metal::float4 q_1 = _e11 * metal::float4(p_2 + (n_2 * (1.5 * _e15)), 1.0);
    metal::float2 uv = metal::float2((q_1.x * 0.5) + 0.5, 0.5 - (q_1.y * 0.5));
    if (!(metal::any(uv < metal::float2(0.0)))) {
        local_6 = metal::any(uv > metal::float2(1.0));
    } else {
        local_6 = true;
    }
    bool _e46 = local_6;
    if (!(_e46)) {
        local_7 = q_1.z > 1.0;
    } else {
        local_7 = true;
    }
    bool _e54 = local_7;
    if (!(_e54)) {
        local_8 = q_1.z < 0.0;
    } else {
        local_8 = true;
    }
    bool _e62 = local_8;
    if (_e62) {
        return 1.0;
    }
    float texel = 1.0 / static_cast<float>(metal::uint2(shadow_tex.get_width(), shadow_tex.get_height()).x);
    float depth = q_1.z - 0.0005;
    float _e75 = s;
    float _e83 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(-1.0, -1.0) * texel), depth);
    s = _e75 + _e83;
    float _e85 = s;
    float _e93 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(-1.0, 0.0) * texel), depth);
    s = _e85 + _e93;
    float _e95 = s;
    float _e103 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(-1.0, 1.0) * texel), depth);
    s = _e95 + _e103;
    float _e105 = s;
    float _e113 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(0.0, -1.0) * texel), depth);
    s = _e105 + _e113;
    float _e115 = s;
    float _e123 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(0.0, 0.0) * texel), depth);
    s = _e115 + _e123;
    float _e125 = s;
    float _e133 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(0.0, 1.0) * texel), depth);
    s = _e125 + _e133;
    float _e135 = s;
    float _e143 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(1.0, -1.0) * texel), depth);
    s = _e135 + _e143;
    float _e145 = s;
    float _e153 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(1.0, 0.0) * texel), depth);
    s = _e145 + _e153;
    float _e155 = s;
    float _e163 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(1.0, 1.0) * texel), depth);
    s = _e155 + _e163;
    float _e165 = s;
    return _e165 / 9.0;
}

struct shadeInput {
};
[[max_total_threads_per_threadgroup(64)]] kernel void shade(
  metal::uint3 wg [[threadgroup_position_in_grid]]
, metal::uint3 lid [[thread_position_in_threadgroup]]
, device type_1 const& luts [[buffer(5)]]
, constant Frame& frame [[buffer(0)]]
, device type_7 const& loft_params [[buffer(2)]]
, device type_1 const& rows [[buffer(3)]]
, constant KindParams& kp [[buffer(4)]]
, metal::texture2d<uint, metal::access::sample> vis_tex [[texture(0)]]
, metal::texture2d<float, metal::access::write> hdr [[texture(1)]]
, device type_10 const& tiles [[buffer(6)]]
, metal::depth2d<float, metal::access::sample> shadow_tex [[texture(2)]]
, metal::sampler shadow_smp [[sampler(0)]]
, constant _mslBufferSizes& _buffer_sizes [[buffer(7)]]
) {
    bool local = {};
    bool local_1 = {};
    metal::float3 g = metal::float3(0.0);
    metal::float3 nl = metal::float3(0.0, 1.0, 0.0);
    float occ = 0.0;
    float w = 1.0;
    uint i = 0u;
    metal::float3 q = {};
    float h = {};
    uint _e5 = frame.cold.x;
    if (_e5 == LOFT_NONCE) {
        return;
    }
    uint _e11 = kp.kind_id;
    uint _e15 = frame.size.w;
    uint tile = tiles[metal::min(unsigned((_e11 * _e15) + wg.x), (_buffer_sizes.size7 - 0 - 4) / 4)];
    metal::uint2 px_1 = (metal::uint2(tile & 65535u, tile >> 16u) * 8u) + lid.xy;
    uint _e34 = frame.size.x;
    if (!((px_1.x >= _e34))) {
        uint _e43 = frame.size.y;
        local = px_1.y >= _e43;
    } else {
        local = true;
    }
    bool _e46 = local;
    if (_e46) {
        return;
    }
    uint clamped_lod_e49 = metal::min(uint(0), vis_tex.get_num_mip_levels() - 1);
    metal::uint4 _e49 = vis_tex.read(metal::min(metal::uint2(px_1), metal::uint2(vis_tex.get_width(clamped_lod_e49), vis_tex.get_height(clamped_lod_e49)) - 1), clamped_lod_e49);
    metal::uint2 v_4 = _e49.xy;
    if (!((v_4.x == LOFT_EMPTY))) {
        uint _e62 = kp.kind_id;
        local_1 = (v_4.x >> 24u) != _e62;
    } else {
        local_1 = true;
    }
    bool _e65 = local_1;
    if (_e65) {
        return;
    }
    Row _e69 = load_row(v_4.x & 16777215u, rows, _buffer_sizes);
    metal::float3 _e74 = loft_ray(static_cast<metal::float2>(px_1) + metal::float2(0.5), frame);
    LoftXform _e75 = loft_pose(_e69);
    LoftXform _e76 = loft_xf_inv(_e75);
    float t = as_type<float>(v_4.y);
    metal::float4 _e81 = frame.eye;
    metal::float3 p_3 = _e81.xyz + (_e74 * t);
    metal::float3 _e85 = loft_xf_pt(_e76, p_3);
    float e = 0.0005 * metal::max(1.0, 0.25 * t);
    uint2 loop_bound_1 = uint2(4294967295u);
    bool loop_init_1 = true;
    while(true) {
        if (metal::all(loop_bound_1 == uint2(0u))) { break; }
        loop_bound_1 -= uint2(loop_bound_1.y == 0u, 1u);
        if (!loop_init_1) {
            uint _e160 = i;
            i = _e160 + 1u;
        }
        loop_init_1 = false;
        uint _e106 = i;
        if (_e106 < 9u) {
        } else {
            break;
        }
        {
            uint _e110 = i;
            q = _e85 + (LOFT_TETRA.inner[metal::min(unsigned(metal::min(_e110, 3u)), 3u)] * e);
            h = 0.0;
            uint _e119 = i;
            if (_e119 >= 4u) {
                uint _e122 = i;
                if (_e122 == 4u) {
                    metal::float3 _e125 = g;
                    nl = metal::normalize(_e125);
                }
                uint _e127 = i;
                h = 0.02 + (0.06 * static_cast<float>(_e127 - 4u));
                metal::float3 _e135 = nl;
                float _e136 = h;
                q = _e85 + (_e135 * _e136);
            }
            metal::float3 _e139 = q;
            float _e140 = q_trace(_e69, _e139);
            uint _e141 = i;
            if (_e141 < 4u) {
                metal::float3 _e144 = g;
                uint _e146 = i;
                g = _e144 + (LOFT_TETRA.inner[metal::min(unsigned(_e146), 3u)] * _e140);
            } else {
                float _e150 = occ;
                float _e151 = h;
                float _e153 = w;
                occ = _e150 + ((_e151 - _e140) * _e153);
                float _e156 = w;
                w = _e156 * 0.8;
            }
        }
    }
    float _e162 = occ;
    float ao = metal::clamp(1.0 - (2.0 * _e162), 0.0, 1.0);
    metal::float3 _e170 = nl;
    metal::float3 _e171 = loft_xf_vec(_e75, _e170);
    metal::float3 n_3 = metal::normalize(_e171);
    metal::float3 _e173 = nl;
    Bsdf _e174 = q_material(_e69, _e85, _e173);
    metal::float4 _e177 = frame.sun;
    metal::float3 sun = metal::normalize(_e177.xyz);
    float _e182 = loft_shadow(p_3, n_3, frame, shadow_tex, shadow_smp);
    metal::float3 _e183 = loft_user_sun_sky(_e174, n_3, -(_e74), sun, _e182, ao, luts, loft_params, _buffer_sizes);
    hdr.write(metal::float4(_e183, 1.0), metal::uint2(px_1));
    return;
}
