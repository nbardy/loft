// language: metal3.2
#include <metal_stdlib>
#include <simd/simd.h>

using metal::uint;

struct _mslBufferSizes {
    uint size1;
};

typedef float type_1[1];
struct Frame {
    metal::float4x4 view_proj;
    metal::float4x4 inv_view_proj;
    metal::float4 eye;
    metal::float4 sun;
    metal::uint4 size;
    metal::uint4 cold;
    metal::float4x4 light_vp;
};
struct LoftXform {
    metal::float3x3 r;
    metal::float3 t;
};
struct Row {
    LoftXform r_pose;
    float r_jaw_open;
    float r_scale;
    float r_aggro;
    char _pad4[4];
    metal::float3 r_tint;
    metal::float3 loft_lo;
    metal::packed_float3 loft_hi;
    float loft_lip;
};
struct KindParams {
    uint kind_id;
    uint base;
    uint n_rows;
    uint pad;
};
struct type_10 {
    uint inner[36];
};
struct VsOut {
    metal::float4 pos;
    metal::packed_float3 wp;
    uint row;
};
struct FsOut {
    metal::uint2 vis;
    float depth;
    char _pad2[4];
};
struct type_12 {
    metal::float3 inner[4];
};
constant uint LOFT_NONCE = 4294967295u;
constant uint LOFT_EMPTY = 4294967295u;
constant uint STRIDE = 25u;
constant type_10 LOFT_CUBE = type_10 {{1u, 3u, 7u, 1u, 7u, 5u, 0u, 6u, 2u, 0u, 4u, 6u, 2u, 6u, 7u, 2u, 7u, 3u, 0u, 1u, 5u, 0u, 5u, 4u, 4u, 5u, 7u, 4u, 7u, 6u, 0u, 2u, 3u, 0u, 3u, 1u}};
constant type_12 LOFT_TETRA = type_12 {{metal::float3(1.0, -1.0, -1.0), metal::float3(-1.0, -1.0, 1.0), metal::float3(-1.0, 1.0, -1.0), metal::float3(1.0, 1.0, 1.0)}};

metal::float3 loft_xf_pt(
    LoftXform x,
    metal::float3 p
) {
    return (x.r * p) + x.t;
}

metal::float3 loft_xf_vec(
    LoftXform x_1,
    metal::float3 v_1
) {
    return x_1.r * v_1;
}

LoftXform loft_xf_inv(
    LoftXform x_2
) {
    metal::float3x3 rt = metal::transpose(x_2.r);
    return LoftXform {rt, -((rt * x_2.t))};
}

metal::float3 loft_rot_x(
    metal::float3 p_1,
    float a
) {
    float s = metal::sin(a);
    float c = metal::cos(a);
    return metal::float3(p_1.x, (c * p_1.y) + (s * p_1.z), (c * p_1.z) - (s * p_1.y));
}

float loft_unit(
    float e0_,
    float e1_,
    float x_3
) {
    return metal::clamp((x_3 - e0_) / (e1_ - e0_), 0.0, 1.0);
}

float loft_smootherstep(
    float e0_1,
    float e1_1,
    float x_4
) {
    float _e3 = loft_unit(e0_1, e1_1, x_4);
    return ((_e3 * _e3) * _e3) * ((((6.0 * _e3) - 15.0) * _e3) + 10.0);
}

Row load_row(
    uint i_1,
    device type_1 const& rows,
    constant _mslBufferSizes& _buffer_sizes
) {
    uint o = i_1 * STRIDE;
    float _e7 = rows[metal::min(unsigned(o + 0u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e12 = rows[metal::min(unsigned(o + 1u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e17 = rows[metal::min(unsigned(o + 2u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e22 = rows[metal::min(unsigned(o + 3u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e27 = rows[metal::min(unsigned(o + 4u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e32 = rows[metal::min(unsigned(o + 5u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e37 = rows[metal::min(unsigned(o + 6u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e42 = rows[metal::min(unsigned(o + 7u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e47 = rows[metal::min(unsigned(o + 8u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e56 = rows[metal::min(unsigned(o + 9u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e61 = rows[metal::min(unsigned(o + 10u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e66 = rows[metal::min(unsigned(o + 11u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e73 = rows[metal::min(unsigned(o + 12u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e78 = rows[metal::min(unsigned(o + 13u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e83 = rows[metal::min(unsigned(o + 14u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e88 = rows[metal::min(unsigned(o + 15u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e93 = rows[metal::min(unsigned(o + 16u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e98 = rows[metal::min(unsigned(o + 17u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e104 = rows[metal::min(unsigned(o + 18u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e109 = rows[metal::min(unsigned(o + 19u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e114 = rows[metal::min(unsigned(o + 20u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e120 = rows[metal::min(unsigned(o + 21u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e125 = rows[metal::min(unsigned(o + 22u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e130 = rows[metal::min(unsigned(o + 23u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    float _e136 = rows[metal::min(unsigned(o + 24u), (_buffer_sizes.size1 - 0 - 4) / 4)];
    return Row {LoftXform {metal::float3x3(metal::float3(_e7, _e12, _e17), metal::float3(_e22, _e27, _e32), metal::float3(_e37, _e42, _e47)), metal::float3(_e56, _e61, _e66)}, _e73, _e78, _e83, {}, metal::float3(_e88, _e93, _e98), metal::float3(_e104, _e109, _e114), metal::float3(_e120, _e125, _e130), _e136};
}

LoftXform loft_pose(
    Row r
) {
    return r.r_pose;
}

float loft_user_smin(
    float loft_local_a,
    float loft_local_b,
    float loft_local_k
) {
    float loft_local_h = metal::max(loft_local_k - metal::abs(loft_local_a - loft_local_b), 0.0) / loft_local_k;
    return metal::min(loft_local_a, loft_local_b) - (((loft_local_h * loft_local_h) * loft_local_k) * 0.25);
}

float loft_user_box_sdf(
    metal::float3 loft_local_v,
    metal::float3 loft_local_half
) {
    metal::float3 loft_local_q = metal::abs(loft_local_v.xyz) - loft_local_half;
    return metal::length(metal::max(loft_local_q, metal::float3(0.0))) + metal::min(metal::max(loft_local_q.x, metal::max(loft_local_q.y, loft_local_q.z)), 0.0);
}

float loft_user_round_box(
    metal::float3 loft_local_v_1,
    metal::float3 loft_local_half_1,
    float loft_local_r
) {
    float _e5 = loft_user_box_sdf(loft_local_v_1, loft_local_half_1 - metal::float3(loft_local_r));
    return _e5 - loft_local_r;
}

float loft_user_ssub(
    float loft_local_a_1,
    float loft_local_b_1,
    float loft_local_k_1
) {
    float _e4 = loft_user_smin(-(loft_local_a_1), loft_local_b_1, loft_local_k_1);
    return -(_e4);
}

float loft_user_capsule(
    metal::float3 loft_local_p,
    metal::float3 loft_local_a_2,
    metal::float3 loft_local_b_2,
    float loft_local_r_1
) {
    metal::float3 loft_local_pa = loft_local_p - loft_local_a_2;
    metal::float3 loft_local_ba = loft_local_b_2 - loft_local_a_2;
    float loft_local_h_1 = metal::clamp(metal::dot(loft_local_pa, loft_local_ba) / metal::max(metal::dot(loft_local_ba, loft_local_ba), 0.000000000001), 0.0, 1.0);
    return metal::length(loft_local_pa - (loft_local_ba * loft_local_h_1)) - loft_local_r_1;
}

float q_trace(
    Row loft_local_self,
    metal::float3 loft_local_p_1
) {
    metal::float3 loft_map_3_jaw_s0_ = static_cast<metal::float3>(loft_local_p_1.xyz / metal::float3(loft_local_self.r_scale));
    float _e16 = loft_user_capsule(loft_map_3_jaw_s0_, metal::float3(0.0, 0.0, -0.75), metal::float3(0.0, 0.02, -0.05), 0.13);
    float _e27 = loft_user_round_box(loft_map_3_jaw_s0_ - metal::float3(0.0, 0.0, 0.32), metal::float3(0.3, 0.24, 0.42), 0.16);
    float _e37 = loft_user_box_sdf(loft_map_3_jaw_s0_ - metal::float3(0.0, -0.34, 0.8), metal::float3(0.42, 0.16, 0.3));
    float _e39 = loft_user_ssub(_e27, _e37, 0.05);
    float _e49 = loft_user_capsule(loft_map_3_jaw_s0_, metal::float3(0.0, -0.1, 0.6), metal::float3(0.0, -0.06, 1.45), 0.11);
    metal::float3 loft_map_3_jaw_t0_ = metal::float3(-0.0, -0.1, -0.6);
    metal::float3 loft_map_3_jaw_s1_ = loft_map_3_jaw_s0_ + loft_map_3_jaw_t0_;
    float loft_map_3_jaw_a1_ = -(loft_local_self.r_jaw_open);
    metal::float3 _e57 = loft_rot_x(loft_map_3_jaw_s1_, loft_map_3_jaw_a1_);
    float _e67 = loft_smootherstep(0.1, 0.9, _e57.z);
    float loft_local_teeth = (0.025 * metal::sin(14.0 * _e57.z)) * _e67;
    float _e78 = loft_user_capsule(_e57, metal::float3(0.0, 0.0, 0.0), metal::float3(0.0, -0.05, 0.95), 0.1);
    float loft_local_dactyl = _e78 - loft_local_teeth;
    float _e82 = loft_user_smin(_e16, _e39, 0.08);
    float _e84 = loft_user_smin(_e82, _e49, 0.06);
    float _e86 = loft_user_smin(_e84, loft_local_dactyl, 0.05);
    return loft_local_self.r_scale * _e86;
}

metal::float2 loft_box(
    metal::float3 ro_1,
    metal::float3 rd_1,
    metal::float3 lo,
    metal::float3 hi
) {
    metal::float3 inv = metal::float3(1.0) / rd_1;
    metal::float3 a_1 = (lo - ro_1) * inv;
    metal::float3 b = (hi - ro_1) * inv;
    metal::float3 n = metal::min(a_1, b);
    metal::float3 f = metal::max(a_1, b);
    return metal::float2(metal::max(metal::max(n.x, n.y), n.z), metal::min(metal::min(f.x, f.y), f.z));
}

struct fsInput {
    metal::float3 wp [[user(loc0), center_perspective]];
    uint row [[user(loc1), flat]];
};
struct fsOutput {
    metal::uint2 vis [[color(0)]];
    float depth [[depth(any)]];
};
fragment fsOutput fs(
  fsInput varyings [[stage_in]]
, metal::float4 pos [[position]]
, constant Frame& frame [[buffer(0)]]
, device type_1 const& rows [[buffer(3)]]
, constant KindParams& kp [[buffer(4)]]
, constant _mslBufferSizes& _buffer_sizes [[buffer(6)]]
) {
    const VsOut v = { pos, varyings.wp, varyings.row };
    metal::float3 ro = {};
    metal::float3 rd = {};
    float t = {};
    bool hit = false;
    uint i = 0u;
    uint _e4 = frame.cold.x;
    if (_e4 == LOFT_NONCE) {
        metal::discard_fragment();
    }
    Row _e8 = load_row(v.row, rows, _buffer_sizes);
    metal::float4 _e11 = frame.eye;
    ro = _e11.xyz;
    metal::float3 _e15 = ro;
    rd = metal::normalize(v.wp - _e15);
    uint _e22 = frame.cold.y;
    if (_e22 == 1u) {
        metal::float4 _e27 = frame.eye;
        rd = _e27.xyz;
        metal::float3 _e30 = rd;
        ro = v.wp - (_e30 * ((2.0 * metal::length(_e8.loft_hi - _e8.loft_lo)) + 1.0));
    }
    metal::float3 _e41 = ro;
    metal::float3 _e42 = rd;
    metal::float2 _e45 = loft_box(_e41, _e42, _e8.loft_lo, _e8.loft_hi);
    LoftXform _e46 = loft_pose(_e8);
    LoftXform _e47 = loft_xf_inv(_e46);
    metal::float3 _e48 = ro;
    metal::float3 _e49 = loft_xf_pt(_e47, _e48);
    metal::float3 _e50 = rd;
    metal::float3 _e51 = loft_xf_vec(_e47, _e50);
    t = metal::max(_e45.x, 0.0);
    float step = 1.0 / _e8.loft_lip;
    uint2 loop_bound = uint2(4294967295u);
    bool loop_init = true;
    while(true) {
        if (metal::all(loop_bound == uint2(0u))) { break; }
        loop_bound -= uint2(loop_bound.y == 0u, 1u);
        if (!loop_init) {
            uint _e84 = i;
            i = _e84 + 1u;
        }
        loop_init = false;
        uint _e63 = i;
        if (_e63 < 192u) {
        } else {
            break;
        }
        {
            float _e66 = t;
            float _e69 = q_trace(_e8, _e49 + (_e51 * _e66));
            float _e70 = t;
            if (_e69 < (0.0001 + (0.0002 * _e70))) {
                hit = true;
                break;
            }
            float _e77 = t;
            t = _e77 + (_e69 * step);
            float _e80 = t;
            if (_e80 > _e45.y) {
                break;
            }
        }
    }
    bool _e86 = hit;
    if (!(_e86)) {
        metal::discard_fragment();
    }
    metal::float4x4 _e90 = frame.view_proj;
    metal::float3 _e91 = ro;
    metal::float3 _e92 = rd;
    float _e93 = t;
    metal::float4 clip = _e90 * metal::float4(_e91 + (_e92 * _e93), 1.0);
    uint _e101 = kp.kind_id;
    float _e106 = t;
    const auto _tmp = FsOut {metal::uint2((_e101 << 24u) | v.row, as_type<uint>(_e106)), clip.z / clip.w};
    return fsOutput { _tmp.vis, _tmp.depth };
}
