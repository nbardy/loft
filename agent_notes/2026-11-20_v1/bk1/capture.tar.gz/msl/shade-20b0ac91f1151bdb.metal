// language: metal3.2
#include <metal_stdlib>
#include <simd/simd.h>

using metal::uint;

struct _mslBufferSizes {
    uint size0;
    uint size2;
    uint size3;
    uint size7;
};

typedef float type_1[1];
struct Frame {
    metal::float4x4 view_proj;
    metal::float4x4 inv_view_proj;
    metal::float4 eye;
    metal::float4 sun;
    metal::uint4 size;
    metal::uint4 cold;
    metal::float4x4 light_vp;
};
typedef metal::float4 type_7[1];
struct LoftXform {
    metal::float3x3 r;
    metal::float3 t;
};
struct LoftFrame {
    metal::float3 origin;
    metal::float3 tangent;
    metal::float3 normal;
    metal::float3 binormal;
};
struct Row {
    LoftXform r_pose;
    metal::float3 r_tint;
    metal::float3 loft_lo;
    metal::packed_float3 loft_hi;
    float loft_lip;
};
struct KindParams {
    uint kind_id;
    uint base;
    uint n_rows;
    uint pad;
};
typedef uint type_10[1];
struct Bsdf {
    metal::packed_float3 l0_0_;
    float l0_1_;
    float l0_2_;
    float l1_0_;
    float l1_1_;
    float l1_2_;
    float l2_0_;
    float l2_1_;
    char _pad8[8];
};
struct LoftPreparedBsdf {
    float l0_1_;
    char _pad1[12];
    metal::float3 l0_2_;
    metal::float3 l0_3_;
    metal::float2 l0_4_;
    float l1_0_;
    char _pad5[4];
    metal::float2 l1_1_;
    char _pad6[8];
    metal::float3 l1_2_;
    metal::packed_float3 l1_3_;
    float l2_0_;
    metal::float2 l2_1_;
    float l2_2_;
    char _pad11[4];
};
struct type_13 {
    metal::float3 inner[12];
};
constant uint LOFT_NONCE = 4294967295u;
constant uint LOFT_EMPTY = 4294967295u;
constant uint STRIDE = 22u;
constant float loft_const_TAU = 6.2831855;

float loft_ggx_word(
    uint i,
    device type_1 const& luts,
    constant _mslBufferSizes& _buffer_sizes
) {
    float _e8 = luts[metal::min(unsigned(((1 + (_buffer_sizes.size0 - 0 - 4) / 4) - 1122u) + i), (_buffer_sizes.size0 - 0 - 4) / 4)];
    return _e8;
}

uint naga_f2u32(float value) {
    return static_cast<uint>(metal::clamp(value, 0.0, 4294967000.0));
}

metal::float2 loft_ggx_energy(
    float roughness,
    float mu,
    device type_1 const& luts,
    constant _mslBufferSizes& _buffer_sizes
) {
    float r_1 = metal::clamp(roughness, 0.0, 1.0) * 32.0;
    float v_3 = metal::sqrt(metal::clamp(mu, 0.0, 1.0)) * 32.0;
    uint i_5 = metal::min(naga_f2u32(r_1), 31u);
    uint j = metal::min(naga_f2u32(v_3), 31u);
    uint base = i_5 * 34u;
    float b_2 = v_3 - static_cast<float>(j);
    float _e24 = loft_ggx_word(base + j, luts, _buffer_sizes);
    float _e28 = loft_ggx_word((base + j) + 1u, luts, _buffer_sizes);
    float e0_ = metal::mix(_e24, _e28, b_2);
    float _e33 = loft_ggx_word((base + 34u) + j, luts, _buffer_sizes);
    float _e39 = loft_ggx_word(((base + 34u) + j) + 1u, luts, _buffer_sizes);
    float e1_ = metal::mix(_e33, _e39, b_2);
    float _e43 = loft_ggx_word(base + 33u, luts, _buffer_sizes);
    float _e47 = loft_ggx_word(base + 67u, luts, _buffer_sizes);
    return metal::mix(metal::float2(e0_, _e43), metal::float2(e1_, _e47), r_1 - static_cast<float>(i_5)) / metal::float2(65535.0);
}

metal::float3 loft_xf_pt(
    LoftXform x,
    metal::float3 p
) {
    return (x.r * p) + x.t;
}

metal::float3 loft_xf_vec(
    LoftXform x_1,
    metal::float3 v
) {
    return x_1.r * v;
}

LoftXform loft_xf_inv(
    LoftXform x_2
) {
    metal::float3x3 rt = metal::transpose(x_2.r);
    return LoftXform {rt, -((rt * x_2.t))};
}

metal::float3 loft_ray(
    metal::float2 px,
    constant Frame& frame
) {
    uint _e5 = frame.size.x;
    uint _e16 = frame.size.y;
    metal::float2 ndc = metal::float2(((px.x / static_cast<float>(_e5)) * 2.0) - 1.0, 1.0 - ((px.y / static_cast<float>(_e16)) * 2.0));
    metal::float4x4 _e26 = frame.inv_view_proj;
    metal::float4 far = _e26 * metal::float4(ndc, 1.0, 1.0);
    metal::float4 _e37 = frame.eye;
    return metal::normalize((far.xyz / metal::float3(far.w)) - _e37.xyz);
}

Row load_row(
    uint i_1,
    device type_1 const& rows,
    constant _mslBufferSizes& _buffer_sizes
) {
    uint o = i_1 * STRIDE;
    float _e7 = rows[metal::min(unsigned(o + 0u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e12 = rows[metal::min(unsigned(o + 1u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e17 = rows[metal::min(unsigned(o + 2u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e22 = rows[metal::min(unsigned(o + 3u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e27 = rows[metal::min(unsigned(o + 4u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e32 = rows[metal::min(unsigned(o + 5u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e37 = rows[metal::min(unsigned(o + 6u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e42 = rows[metal::min(unsigned(o + 7u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e47 = rows[metal::min(unsigned(o + 8u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e56 = rows[metal::min(unsigned(o + 9u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e61 = rows[metal::min(unsigned(o + 10u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e66 = rows[metal::min(unsigned(o + 11u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e73 = rows[metal::min(unsigned(o + 12u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e78 = rows[metal::min(unsigned(o + 13u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e83 = rows[metal::min(unsigned(o + 14u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e89 = rows[metal::min(unsigned(o + 15u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e94 = rows[metal::min(unsigned(o + 16u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e99 = rows[metal::min(unsigned(o + 17u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e105 = rows[metal::min(unsigned(o + 18u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e110 = rows[metal::min(unsigned(o + 19u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e115 = rows[metal::min(unsigned(o + 20u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    float _e121 = rows[metal::min(unsigned(o + 21u), (_buffer_sizes.size3 - 0 - 4) / 4)];
    return Row {LoftXform {metal::float3x3(metal::float3(_e7, _e12, _e17), metal::float3(_e22, _e27, _e32), metal::float3(_e37, _e42, _e47)), metal::float3(_e56, _e61, _e66)}, metal::float3(_e73, _e78, _e83), metal::float3(_e89, _e94, _e99), metal::float3(_e105, _e110, _e115), _e121};
}

LoftXform loft_pose(
    Row r
) {
    return r.r_pose;
}

LoftFrame loft_lut(
    int i_2,
    uint off,
    uint n_1,
    device type_1 const& luts,
    constant _mslBufferSizes& _buffer_sizes
) {
    uint o_1 = (off + static_cast<uint>(metal::clamp(i_2, 0, as_type<int>(as_type<uint>(static_cast<int>(n_1)) - as_type<uint>(1))))) * 12u;
    float _e14 = luts[metal::min(unsigned(o_1), (_buffer_sizes.size0 - 0 - 4) / 4)];
    float _e19 = luts[metal::min(unsigned(o_1 + 1u), (_buffer_sizes.size0 - 0 - 4) / 4)];
    float _e24 = luts[metal::min(unsigned(o_1 + 2u), (_buffer_sizes.size0 - 0 - 4) / 4)];
    float _e30 = luts[metal::min(unsigned(o_1 + 3u), (_buffer_sizes.size0 - 0 - 4) / 4)];
    float _e35 = luts[metal::min(unsigned(o_1 + 4u), (_buffer_sizes.size0 - 0 - 4) / 4)];
    float _e40 = luts[metal::min(unsigned(o_1 + 5u), (_buffer_sizes.size0 - 0 - 4) / 4)];
    float _e46 = luts[metal::min(unsigned(o_1 + 6u), (_buffer_sizes.size0 - 0 - 4) / 4)];
    float _e51 = luts[metal::min(unsigned(o_1 + 7u), (_buffer_sizes.size0 - 0 - 4) / 4)];
    float _e56 = luts[metal::min(unsigned(o_1 + 8u), (_buffer_sizes.size0 - 0 - 4) / 4)];
    float _e62 = luts[metal::min(unsigned(o_1 + 9u), (_buffer_sizes.size0 - 0 - 4) / 4)];
    float _e67 = luts[metal::min(unsigned(o_1 + 10u), (_buffer_sizes.size0 - 0 - 4) / 4)];
    float _e72 = luts[metal::min(unsigned(o_1 + 11u), (_buffer_sizes.size0 - 0 - 4) / 4)];
    return LoftFrame {metal::float3(_e14, _e19, _e24), metal::float3(_e30, _e35, _e40), metal::float3(_e46, _e51, _e56), metal::float3(_e62, _e67, _e72)};
}

LoftFrame loft_blend(
    int i_3,
    uint off_1,
    uint n_2,
    metal::float4 w,
    device type_1 const& luts,
    constant _mslBufferSizes& _buffer_sizes
) {
    LoftFrame _e6 = loft_lut(as_type<int>(as_type<uint>(i_3) - as_type<uint>(1)), off_1, n_2, luts, _buffer_sizes);
    LoftFrame _e7 = loft_lut(i_3, off_1, n_2, luts, _buffer_sizes);
    LoftFrame _e10 = loft_lut(as_type<int>(as_type<uint>(i_3) + as_type<uint>(1)), off_1, n_2, luts, _buffer_sizes);
    LoftFrame _e13 = loft_lut(as_type<int>(as_type<uint>(i_3) + as_type<uint>(2)), off_1, n_2, luts, _buffer_sizes);
    return LoftFrame {(((_e6.origin * w.x) + (_e7.origin * w.y)) + (_e10.origin * w.z)) + (_e13.origin * w.w), (((_e6.tangent * w.x) + (_e7.tangent * w.y)) + (_e10.tangent * w.z)) + (_e13.tangent * w.w), (((_e6.normal * w.x) + (_e7.normal * w.y)) + (_e10.normal * w.z)) + (_e13.normal * w.w), (((_e6.binormal * w.x) + (_e7.binormal * w.y)) + (_e10.binormal * w.z)) + (_e13.binormal * w.w)};
}

int naga_f2i32(float value) {
    return static_cast<int>(metal::clamp(value, -2147483600.0, 2147483500.0));
}

LoftFrame loft_sample(
    uint off_2,
    uint n_3,
    float lo,
    float hi,
    float t,
    device type_1 const& luts,
    constant _mslBufferSizes& _buffer_sizes
) {
    float s_1 = ((t - lo) / (hi - lo)) * static_cast<float>(n_3 - 1u);
    float i_6 = metal::clamp(metal::floor(s_1), 0.0, static_cast<float>(n_3 - 1u));
    float f = s_1 - i_6;
    float g = 1.0 - f;
    LoftFrame _e58 = loft_blend(naga_f2i32(i_6), off_2, n_3, metal::float4(((g * g) * g) / 6.0, (((((3.0 * f) * f) * f) - ((6.0 * f) * f)) + 4.0) / 6.0, ((((((-3.0 * f) * f) * f) + ((3.0 * f) * f)) + (3.0 * f)) + 1.0) / 6.0, ((f * f) * f) / 6.0), luts, _buffer_sizes);
    return _e58;
}

LoftFrame loft_dsample(
    uint off_3,
    uint n_4,
    float lo_1,
    float hi_1,
    float t_1,
    float dt,
    device type_1 const& luts,
    constant _mslBufferSizes& _buffer_sizes
) {
    float s_2 = ((t_1 - lo_1) / (hi_1 - lo_1)) * static_cast<float>(n_4 - 1u);
    float i_7 = metal::clamp(metal::floor(s_2), 0.0, static_cast<float>(n_4 - 1u));
    float f_1 = s_2 - i_7;
    float g_1 = 1.0 - f_1;
    float k = (static_cast<float>(n_4 - 1u) / (hi_1 - lo_1)) * dt;
    LoftFrame _e56 = loft_blend(naga_f2i32(i_7), off_3, n_4, metal::float4((-(g_1) * g_1) / 2.0, (((3.0 * f_1) * f_1) - (4.0 * f_1)) / 2.0, ((((-3.0 * f_1) * f_1) + (2.0 * f_1)) + 1.0) / 2.0, (f_1 * f_1) / 2.0) * k, luts, _buffer_sizes);
    return _e56;
}

float loft_user_pow5_(
    float loft_local_x
) {
    float loft_local_x2_ = loft_local_x * loft_local_x;
    return (loft_local_x2_ * loft_local_x2_) * loft_local_x;
}

metal::float3 loft_user_fresnel(
    metal::float3 loft_local_f0_,
    float loft_local_mu
) {
    float _e10 = loft_user_pow5_(1.0 - metal::clamp(loft_local_mu, 0.0, 1.0));
    return loft_local_f0_ + ((metal::float3(1.0) - loft_local_f0_) * _e10);
}

float loft_user_ggx_dv(
    float loft_local_nh,
    float loft_local_nv,
    float loft_local_nl,
    float loft_local_rough
) {
    float loft_local_a_3 = metal::max(loft_local_rough * loft_local_rough, 0.002);
    float loft_local_a2_ = loft_local_a_3 * loft_local_a_3;
    float loft_local_q = (1.0 - (loft_local_nh * loft_local_nh)) + ((loft_local_nh * loft_local_nh) * loft_local_a2_);
    float loft_local_gv = loft_local_nl * metal::sqrt(loft_local_a2_ + (((1.0 - loft_local_a2_) * loft_local_nv) * loft_local_nv));
    float loft_local_gl = loft_local_nv * metal::sqrt(loft_local_a2_ + (((1.0 - loft_local_a2_) * loft_local_nl) * loft_local_nl));
    return loft_local_a2_ / (((6.2831855 * loft_local_q) * loft_local_q) * metal::max(loft_local_gv + loft_local_gl, 0.00000001));
}

metal::float3 loft_user_ggx_ms(
    metal::float2 loft_local_eo,
    float loft_local_ei,
    metal::float3 loft_local_favg
) {
    float loft_local_ea = loft_local_eo.y;
    float loft_local_lost = 1.0 - loft_local_ea;
    metal::float3 loft_local_tint = ((loft_local_favg * loft_local_favg) * loft_local_ea) / metal::max(metal::float3(1.0) - (loft_local_favg * loft_local_lost), metal::float3(0.000001));
    return loft_local_tint * ((((1.0 - loft_local_eo.x) * (1.0 - loft_local_ei)) * 0.31830987) / metal::max(loft_local_lost, 0.000001));
}

metal::float3 loft_user_ggx_reflect(
    float loft_local_nh_1,
    float loft_local_nv_1,
    float loft_local_nl_1,
    float loft_local_rough_1,
    metal::float3 loft_local_f_half,
    metal::float3 loft_local_favg_1,
    metal::float2 loft_local_eo_1,
    device type_1 const& luts,
    constant _mslBufferSizes& _buffer_sizes
) {
    metal::float2 _e7 = loft_ggx_energy(loft_local_rough_1, loft_local_nl_1, luts, _buffer_sizes);
    float loft_local_ei_1 = _e7.x;
    float _e9 = loft_user_ggx_dv(loft_local_nh_1, loft_local_nv_1, loft_local_nl_1, loft_local_rough_1);
    metal::float3 _e11 = loft_user_ggx_ms(loft_local_eo_1, loft_local_ei_1, loft_local_favg_1);
    return ((loft_local_f_half * _e9) + _e11) * loft_local_nl_1;
}

metal::float3 loft_user_airy(
    float loft_local_ior,
    float loft_local_thickness_nm,
    float loft_local_mu_1
) {
    float loft_local_cos_t = metal::sqrt(metal::max(1.0 - ((1.0 - (loft_local_mu_1 * loft_local_mu_1)) / (loft_local_ior * loft_local_ior)), 0.0));
    float loft_local_f = (loft_local_ior - 1.0) / (loft_local_ior + 1.0);
    float loft_local_r0_ = loft_local_f * loft_local_f;
    float loft_local_phase = ((12.566371 * loft_local_ior) * loft_local_thickness_nm) * loft_local_cos_t;
    metal::float3 loft_local_c_1 = metal::float3(metal::cos(loft_local_phase / 650.0), metal::cos(loft_local_phase / 532.0), metal::cos(loft_local_phase / 450.0));
    return ((2.0 * loft_local_r0_) * (metal::float3(1.0) - loft_local_c_1)) / (metal::float3(1.0 + (loft_local_r0_ * loft_local_r0_)) - ((2.0 * loft_local_r0_) * loft_local_c_1));
}

LoftPreparedBsdf loft_prepare_bsdf(
    Bsdf b,
    metal::float3 n_5,
    metal::float3 v_1,
    device type_1 const& luts,
    constant _mslBufferSizes& _buffer_sizes
) {
    LoftPreparedBsdf c = {};
    {
        metal::float3 loft_local_albedo_1 = b.l0_0_;
        float loft_local_rough_4 = b.l0_1_;
        float loft_local_metal_1 = b.l0_2_;
        float loft_local_nv_2 = metal::max(metal::dot(n_5, v_1), 0.0);
        c.l0_1_ = loft_local_nv_2;
        metal::float3 loft_local_f0_1 = metal::mix(metal::float3(0.04), loft_local_albedo_1, loft_local_metal_1);
        c.l0_2_ = loft_local_f0_1;
        metal::float3 _e15 = loft_user_fresnel(loft_local_f0_1, loft_local_nv_2);
        c.l0_3_ = _e15;
        metal::float2 _e17 = loft_ggx_energy(loft_local_rough_4, loft_local_nv_2, luts, _buffer_sizes);
        c.l0_4_ = _e17;
    }
    {
        float loft_local_weight_2 = b.l1_0_;
        float loft_local_ior_2 = b.l1_1_;
        float loft_local_thickness_nm_2 = b.l1_2_;
        float loft_local_nv_3 = metal::max(metal::dot(n_5, v_1), 0.0);
        c.l1_0_ = loft_local_nv_3;
        metal::float2 _e27 = loft_ggx_energy(0.3, loft_local_nv_3, luts, _buffer_sizes);
        c.l1_1_ = _e27;
        metal::float3 _e29 = loft_user_airy(loft_local_ior_2, loft_local_thickness_nm_2, loft_local_nv_3);
        c.l1_2_ = _e29;
        metal::float3 _e32 = loft_user_airy(loft_local_ior_2, loft_local_thickness_nm_2, 0.335711);
        metal::float3 _e36 = loft_user_airy(loft_local_ior_2, loft_local_thickness_nm_2, 0.707107);
        metal::float3 _e41 = loft_user_airy(loft_local_ior_2, loft_local_thickness_nm_2, 0.941965);
        metal::float3 loft_local_favg_2 = (((5.0 * _e32) + (8.0 * _e36)) + (5.0 * _e41)) / metal::float3(18.0);
        c.l1_3_ = loft_local_favg_2;
    }
    {
        float loft_local_weight_3 = b.l2_0_;
        float loft_local_rough_5 = b.l2_1_;
        float loft_local_nv_4 = metal::max(metal::dot(n_5, v_1), 0.0);
        c.l2_0_ = loft_local_nv_4;
        metal::float2 _e55 = loft_ggx_energy(loft_local_rough_5, loft_local_nv_4, luts, _buffer_sizes);
        c.l2_1_ = _e55;
        metal::float3 _e59 = loft_user_fresnel(metal::float3(0.04), loft_local_nv_4);
        float loft_local_fv = _e59.x;
        c.l2_2_ = loft_local_fv;
    }
    LoftPreparedBsdf _e62 = c;
    return _e62;
}

metal::float4 loft_prepared_lobe_0_(
    metal::float3 loft_local_albedo,
    float loft_local_rough_2,
    float loft_local_metal,
    metal::float3 loft_local_n,
    metal::float3 loft_local_v,
    metal::float3 loft_local_l,
    LoftPreparedBsdf prepared,
    device type_1 const& luts,
    constant _mslBufferSizes& _buffer_sizes
) {
    metal::float3 loft_local_spec = metal::float3(0.0);
    bool local_2 = {};
    float loft_local_nl_2 = metal::max(metal::dot(loft_local_n, loft_local_l), 0.0);
    float loft_local_nv_5 = prepared.l0_1_;
    metal::float3 loft_local_f0_2 = prepared.l0_2_;
    metal::float3 loft_local_fv_1 = prepared.l0_3_;
    metal::float2 loft_local_eo_2 = prepared.l0_4_;
    if (loft_local_nl_2 > 0.0) {
        local_2 = loft_local_nv_5 > 0.0;
    } else {
        local_2 = false;
    }
    bool _e24 = local_2;
    if (_e24) {
        metal::float3 loft_local_h_1 = metal::normalize(loft_local_v + loft_local_l);
        metal::float3 _e28 = loft_user_fresnel(loft_local_f0_2, metal::dot(loft_local_v, loft_local_h_1));
        metal::float3 _e41 = loft_user_ggx_reflect(metal::clamp(metal::dot(loft_local_n, loft_local_h_1), 0.0, 1.0), loft_local_nv_5, loft_local_nl_2, loft_local_rough_2, _e28, (metal::float3(1.0) + (20.0 * loft_local_f0_2)) / metal::float3(21.0), loft_local_eo_2, luts, _buffer_sizes);
        loft_local_spec = _e41;
    }
    metal::float3 loft_local_diffuse = ((loft_local_albedo * (1.0 - loft_local_metal)) * (metal::float3(1.0) - loft_local_fv_1)) * (0.31830987 * loft_local_nl_2);
    metal::float3 _e52 = loft_local_spec;
    return metal::float4(loft_local_diffuse + _e52, 1.0 - (prepared.l0_4_.x * metal::dot(loft_local_fv_1, metal::float3(0.2126, 0.7152, 0.0722))));
}

metal::float4 loft_prepared_lobe_1_(
    float loft_local_weight,
    float loft_local_ior_1,
    float loft_local_thickness_nm_1,
    metal::float3 loft_local_n_1,
    metal::float3 loft_local_v_1,
    metal::float3 loft_local_l_1,
    LoftPreparedBsdf prepared_1,
    device type_1 const& luts,
    constant _mslBufferSizes& _buffer_sizes
) {
    metal::float3 loft_local_spec_1 = metal::float3(0.0);
    bool local_3 = {};
    float loft_local_nv_6 = prepared_1.l1_0_;
    metal::float2 loft_local_eo_3 = prepared_1.l1_1_;
    metal::float3 loft_local_fv_2 = prepared_1.l1_2_;
    metal::float3 loft_local_favg_3 = prepared_1.l1_3_;
    float loft_local_nl_3 = metal::dot(loft_local_n_1, loft_local_l_1);
    if (loft_local_nl_3 > 0.0) {
        local_3 = loft_local_nv_6 > 0.0;
    } else {
        local_3 = false;
    }
    bool _e22 = local_3;
    if (_e22) {
        metal::float3 loft_local_h_2 = metal::normalize(loft_local_v_1 + loft_local_l_1);
        metal::float3 _e29 = loft_user_airy(loft_local_ior_1, loft_local_thickness_nm_1, metal::clamp(metal::dot(loft_local_v_1, loft_local_h_2), 0.0, 1.0));
        metal::float3 _e35 = loft_user_ggx_reflect(metal::clamp(metal::dot(loft_local_n_1, loft_local_h_2), 0.0, 1.0), loft_local_nv_6, loft_local_nl_3, 0.3, _e29, loft_local_favg_3, loft_local_eo_3, luts, _buffer_sizes);
        loft_local_spec_1 = _e35;
    }
    metal::float3 _e36 = loft_local_spec_1;
    return metal::float4(loft_local_weight * _e36, 1.0 - ((loft_local_weight * prepared_1.l1_1_.x) * metal::dot(loft_local_fv_2, metal::float3(0.2126, 0.7152, 0.0722))));
}

metal::float4 loft_prepared_lobe_2_(
    float loft_local_weight_1,
    float loft_local_rough_3,
    metal::float3 loft_local_n_2,
    metal::float3 loft_local_v_2,
    metal::float3 loft_local_l_2,
    LoftPreparedBsdf prepared_2,
    device type_1 const& luts,
    constant _mslBufferSizes& _buffer_sizes
) {
    metal::float3 loft_local_spec_2 = metal::float3(0.0);
    bool local_4 = {};
    float loft_local_nv_7 = prepared_2.l2_0_;
    metal::float2 loft_local_eo_4 = prepared_2.l2_1_;
    float loft_local_fv_3 = prepared_2.l2_2_;
    float loft_local_nl_4 = metal::dot(loft_local_n_2, loft_local_l_2);
    if (loft_local_nl_4 > 0.0) {
        local_4 = loft_local_nv_7 > 0.0;
    } else {
        local_4 = false;
    }
    bool _e20 = local_4;
    if (_e20) {
        metal::float3 loft_local_h_3 = metal::normalize(loft_local_v_2 + loft_local_l_2);
        metal::float3 _e26 = loft_user_fresnel(metal::float3(0.04), metal::dot(loft_local_v_2, loft_local_h_3));
        metal::float3 _e33 = loft_user_ggx_reflect(metal::clamp(metal::dot(loft_local_n_2, loft_local_h_3), 0.0, 1.0), loft_local_nv_7, loft_local_nl_4, loft_local_rough_3, _e26, metal::float3(0.08571429), loft_local_eo_4, luts, _buffer_sizes);
        loft_local_spec_2 = _e33;
    }
    metal::float3 _e34 = loft_local_spec_2;
    return metal::float4(loft_local_weight_1 * _e34, 1.0 - ((loft_local_weight_1 * prepared_2.l2_1_.x) * loft_local_fv_3));
}

metal::float3 loft_eval_prepared(
    Bsdf b_1,
    metal::float3 n_6,
    metal::float3 v_2,
    metal::float3 l,
    LoftPreparedBsdf prepared_3,
    device type_1 const& luts,
    constant _mslBufferSizes& _buffer_sizes
) {
    bool local_5 = {};
    metal::float3 c_1 = metal::float3(0.0);
    metal::float3 emission = metal::float3(0.0);
    if (metal::dot(n_6, l) <= -0.0) {
        local_5 = metal::dot(l, l) > 0.0;
    } else {
        local_5 = false;
    }
    bool _e14 = local_5;
    if (_e14) {
        return metal::float3(0.0);
    }
    metal::float4 _e26 = loft_prepared_lobe_0_(b_1.l0_0_, b_1.l0_1_, b_1.l0_2_, n_6, v_2, l, prepared_3, luts, _buffer_sizes);
    metal::float3 _e27 = c_1;
    c_1 = (_e27 * _e26.w) + _e26.xyz;
    metal::float4 _e35 = loft_prepared_lobe_1_(b_1.l1_0_, b_1.l1_1_, b_1.l1_2_, n_6, v_2, l, prepared_3, luts, _buffer_sizes);
    metal::float3 _e36 = c_1;
    c_1 = (_e36 * _e35.w) + _e35.xyz;
    metal::float4 _e43 = loft_prepared_lobe_2_(b_1.l2_0_, b_1.l2_1_, n_6, v_2, l, prepared_3, luts, _buffer_sizes);
    metal::float3 _e44 = c_1;
    c_1 = (_e44 * _e43.w) + _e43.xyz;
    metal::float3 _e49 = c_1;
    metal::float3 _e50 = emission;
    return _e49 + _e50;
}

float loft_user_hash3_(
    int loft_local_x_1,
    int loft_local_y,
    int loft_local_z
) {
    uint loft_local_h = {};
    loft_local_h = ((static_cast<uint>(loft_local_x_1) * 73856093u) ^ (static_cast<uint>(loft_local_y) * 19349663u)) ^ (static_cast<uint>(loft_local_z) * 83492791u);
    uint _e15 = loft_local_h;
    uint _e16 = loft_local_h;
    loft_local_h = (_e15 ^ (_e16 >> 13u)) * 1274126177u;
    uint _e22 = loft_local_h;
    uint _e23 = loft_local_h;
    loft_local_h = _e22 ^ (_e23 >> 16u);
    uint _e27 = loft_local_h;
    return static_cast<float>(_e27 & 16777215u) / 16777216.0;
}

float loft_user_vnoise(
    metal::float3 loft_local_p
) {
    metal::float3 loft_local_i_2 = metal::floor(loft_local_p);
    metal::float3 loft_local_f_1 = loft_local_p - loft_local_i_2;
    metal::float3 loft_local_u_4 = (loft_local_f_1 * loft_local_f_1) * (metal::float3(3.0) - (2.0 * loft_local_f_1));
    int loft_local_x_2 = naga_f2i32(loft_local_i_2.x);
    int loft_local_y_1 = naga_f2i32(loft_local_i_2.y);
    int loft_local_z_1 = naga_f2i32(loft_local_i_2.z);
    float _e16 = loft_user_hash3_(loft_local_x_2, loft_local_y_1, loft_local_z_1);
    float _e19 = loft_user_hash3_(as_type<int>(as_type<uint>(loft_local_x_2) + as_type<uint>(1)), loft_local_y_1, loft_local_z_1);
    float _e24 = loft_user_hash3_(loft_local_x_2, as_type<int>(as_type<uint>(loft_local_y_1) + as_type<uint>(1)), loft_local_z_1);
    float _e29 = loft_user_hash3_(as_type<int>(as_type<uint>(loft_local_x_2) + as_type<uint>(1)), as_type<int>(as_type<uint>(loft_local_y_1) + as_type<uint>(1)), loft_local_z_1);
    float loft_local_a_4 = metal::mix(metal::mix(_e16, _e19, loft_local_u_4.x), metal::mix(_e24, _e29, loft_local_u_4.x), loft_local_u_4.y);
    float _e36 = loft_user_hash3_(loft_local_x_2, loft_local_y_1, as_type<int>(as_type<uint>(loft_local_z_1) + as_type<uint>(1)));
    float _e41 = loft_user_hash3_(as_type<int>(as_type<uint>(loft_local_x_2) + as_type<uint>(1)), loft_local_y_1, as_type<int>(as_type<uint>(loft_local_z_1) + as_type<uint>(1)));
    float _e48 = loft_user_hash3_(loft_local_x_2, as_type<int>(as_type<uint>(loft_local_y_1) + as_type<uint>(1)), as_type<int>(as_type<uint>(loft_local_z_1) + as_type<uint>(1)));
    float _e55 = loft_user_hash3_(as_type<int>(as_type<uint>(loft_local_x_2) + as_type<uint>(1)), as_type<int>(as_type<uint>(loft_local_y_1) + as_type<uint>(1)), as_type<int>(as_type<uint>(loft_local_z_1) + as_type<uint>(1)));
    float loft_local_b_1 = metal::mix(metal::mix(_e36, _e41, loft_local_u_4.x), metal::mix(_e48, _e55, loft_local_u_4.x), loft_local_u_4.y);
    return metal::mix(loft_local_a_4, loft_local_b_1, loft_local_u_4.z);
}

float loft_user_fbm2_(
    metal::float3 loft_local_p_1
) {
    float _e1 = loft_user_vnoise(loft_local_p_1);
    float _e11 = loft_user_vnoise((loft_local_p_1 * 2.03) + metal::float3(1.7, 9.2, 3.1));
    return (0.667 * _e1) + (0.333 * _e11);
}

float loft_user_wave(
    float loft_local_a
) {
    return 0.5 + (0.5 * metal::sin(loft_local_a));
}

float loft_user_rib_jvp(
    float loft_local_u,
    float loft_local_a_1,
    float loft_local_u_t,
    float loft_local_a_t
) {
    float loft_local_c_2 = 0.5 + (0.5 * metal::cos(28.0 * loft_local_u));
    float loft_local_c_t = 0.5 * (-(metal::sin(28.0 * loft_local_u)) * (28.0 * loft_local_u_t));
    return ((((((((0.06 * loft_local_c_t) * loft_local_c_2) + ((0.06 * loft_local_c_2) * loft_local_c_t)) * loft_local_c_2) + (((0.06 * loft_local_c_2) * loft_local_c_2) * loft_local_c_t)) * loft_local_c_2) + ((((0.06 * loft_local_c_2) * loft_local_c_2) * loft_local_c_2) * loft_local_c_t)) * (0.6 + (0.4 * metal::cos(5.0 * loft_local_a_1)))) + (((((0.06 * loft_local_c_2) * loft_local_c_2) * loft_local_c_2) * loft_local_c_2) * (0.4 * (-(metal::sin(5.0 * loft_local_a_1)) * (5.0 * loft_local_a_t))));
}

float loft_user_rib(
    float loft_local_u_1,
    float loft_local_a_2
) {
    float loft_local_c_3 = 0.5 + (0.5 * metal::cos(28.0 * loft_local_u_1));
    return ((((0.06 * loft_local_c_3) * loft_local_c_3) * loft_local_c_3) * loft_local_c_3) * (0.6 + (0.4 * metal::cos(5.0 * loft_local_a_2)));
}

metal::float3 loft_internal_raw_6_776_(
    uint i_4
) {
    return type_13 {{metal::float3(0.3996526, 0.9166667, 0.0), metal::float3(-0.48772362, 0.75, 0.44679487), metal::float3(0.0710099, 0.5833334, -0.80912286), metal::float3(0.5531074, 0.4166667, 0.7214298), metal::float3(-0.95344484, 0.25, -0.16865061), metal::float3(0.84082043, 0.08333331, -0.5348613), metal::float3(-0.25870034, -0.08333337, 0.9623563), metal::float3(-0.44627205, -0.25, -0.8592679), metal::float3(0.85389906, -0.41666663, 0.31184188), metal::float3(-0.7507836, -0.5833334, 0.30991307), metal::float3(0.28034753, -0.75, -0.599087), metal::float3(0.119609706, -0.9166666, 0.38133422)}}.inner[metal::min(unsigned(i_4), 11u)];
}

metal::float3 loft_user_sky_dome(
    metal::float3 loft_local_d,
    device type_7 const& loft_params,
    constant _mslBufferSizes& _buffer_sizes
) {
    bool local_6 = {};
    float loft_local_up = metal::clamp(loft_local_d.y, -1.0, 1.0);
    metal::float4 _e7 = loft_params[metal::min(unsigned(2), (_buffer_sizes.size2 - 0 - 16) / 16)];
    metal::float4 _e11 = loft_params[metal::min(unsigned(1), (_buffer_sizes.size2 - 0 - 16) / 16)];
    metal::float3 loft_local_sky = metal::mix(_e7.xyz, _e11.xyz, metal::sqrt(metal::max(loft_local_up, 0.0)));
    metal::float3 loft_local_ground = metal::mix(metal::float3(0.24, 0.21, 0.16), metal::float3(0.12, 0.1, 0.08), metal::sqrt(metal::max(-(loft_local_up), 0.0)));
    if (!((loft_local_up >= 0.0))) {
        float _e38 = loft_params[metal::min(unsigned(1), (_buffer_sizes.size2 - 0 - 16) / 16)].w;
        local_6 = _e38 != 0.0;
    } else {
        local_6 = true;
    }
    bool _e42 = local_6;
    return _e42 ? loft_local_sky : loft_local_ground;
}

metal::float3 loft_user_sky_patch(
    uint loft_local_i
) {
    metal::float3 _e1 = loft_internal_raw_6_776_(loft_local_i);
    return _e1;
}

metal::float3 loft_user_sun_sky(
    Bsdf loft_local_b,
    metal::float3 loft_local_n_3,
    metal::float3 loft_local_v_3,
    metal::float3 loft_local_sun,
    float loft_local_shadow,
    float loft_local_ao,
    device type_1 const& luts,
    device type_7 const& loft_params,
    constant _mslBufferSizes& _buffer_sizes
) {
    metal::float3 loft_local_c = metal::float3(0.0);
    uint loft_local_i_1 = 0u;
    metal::float3 loft_local_l_3 = {};
    metal::float3 loft_local_e = {};
    LoftPreparedBsdf _e6 = loft_prepare_bsdf(loft_local_b, loft_local_n_3, loft_local_v_3, luts, _buffer_sizes);
    uint2 loop_bound = uint2(4294967295u);
    bool loop_init = true;
    while(true) {
        if (metal::all(loop_bound == uint2(0u))) { break; }
        loop_bound -= uint2(loop_bound.y == 0u, 1u);
        if (!loop_init) {
            uint _e49 = loft_local_i_1;
            loft_local_i_1 = _e49 + 1u;
        }
        loop_init = false;
        uint _e12 = loft_local_i_1;
        if (_e12 < 14u) {
        } else {
            break;
        }
        {
            loft_local_l_3 = metal::float3(0.0);
            loft_local_e = metal::float3(1.0);
            uint _e21 = loft_local_i_1;
            if (_e21 == 1u) {
                loft_local_l_3 = loft_local_sun;
                metal::float4 _e26 = loft_params[metal::min(unsigned(0), (_buffer_sizes.size2 - 0 - 16) / 16)];
                loft_local_e = _e26.xyz * loft_local_shadow;
            }
            uint _e29 = loft_local_i_1;
            if (_e29 >= 2u) {
                uint _e32 = loft_local_i_1;
                metal::float3 _e36 = loft_user_sky_patch(static_cast<uint>(_e32 - 2u));
                loft_local_l_3 = _e36;
                metal::float3 _e37 = loft_local_l_3;
                metal::float3 _e38 = loft_user_sky_dome(_e37, loft_params, _buffer_sizes);
                loft_local_e = _e38 * (0.89011794 * loft_local_ao);
            }
            metal::float3 _e42 = loft_local_c;
            metal::float3 _e43 = loft_local_l_3;
            metal::float3 _e44 = loft_eval_prepared(loft_local_b, loft_local_n_3, loft_local_v_3, _e43, _e6, luts, _buffer_sizes);
            metal::float3 _e45 = loft_local_e;
            loft_local_c = _e42 + (_e44 * _e45);
        }
    }
    metal::float3 _e51 = loft_local_c;
    return _e51;
}

metal::float3 loft_surface_jvp(
    Row loft_local_self,
    float loft_local_u_2,
    float loft_local_v_4,
    float loft_local_u_t_1,
    float loft_local_v_t,
    device type_1 const& luts,
    constant _mslBufferSizes& _buffer_sizes
) {
    LoftFrame _e9 = loft_sample(0u, 256u, 0.0, 1.0, loft_local_u_2, luts, _buffer_sizes);
    LoftFrame _e14 = loft_dsample(0u, 256u, 0.0, 1.0, loft_local_u_2, loft_local_u_t_1, luts, _buffer_sizes);
    float loft_local_a_5 = loft_const_TAU * loft_local_v_4;
    float loft_local_a_t_1 = loft_const_TAU * loft_local_v_t;
    float loft_local_r = 0.26 * metal::exp(2.6 * (loft_local_u_2 - 1.0));
    float loft_local_r_t = 0.26 * (metal::exp(2.6 * (loft_local_u_2 - 1.0)) * (2.6 * loft_local_u_t_1));
    float _e36 = loft_user_rib(loft_local_u_2, loft_local_a_5);
    float _e37 = loft_user_rib_jvp(loft_local_u_2, loft_local_a_5, loft_local_u_t_1, loft_local_a_t_1);
    return (_e14.origin + ((_e14.normal * ((loft_local_r * (1.0 + _e36)) * metal::cos(loft_local_a_5))) + (_e9.normal * ((((loft_local_r_t * (1.0 + _e36)) + (loft_local_r * _e37)) * metal::cos(loft_local_a_5)) + ((loft_local_r * (1.0 + _e36)) * (-(metal::sin(loft_local_a_5)) * loft_local_a_t_1)))))) + ((_e14.binormal * ((loft_local_r * (0.9 + _e36)) * metal::sin(loft_local_a_5))) + (_e9.binormal * ((((loft_local_r_t * (0.9 + _e36)) + (loft_local_r * _e37)) * metal::sin(loft_local_a_5)) + ((loft_local_r * (0.9 + _e36)) * (metal::cos(loft_local_a_5) * loft_local_a_t_1)))));
}

metal::float3 q_surface(
    Row loft_local_self_1,
    float loft_local_u_3,
    float loft_local_v_5,
    device type_1 const& luts,
    constant _mslBufferSizes& _buffer_sizes
) {
    LoftFrame _e7 = loft_sample(0u, 256u, 0.0, 1.0, loft_local_u_3, luts, _buffer_sizes);
    float loft_local_a_6 = loft_const_TAU * loft_local_v_5;
    float loft_local_r_1 = 0.26 * metal::exp(2.6 * (loft_local_u_3 - 1.0));
    float _e17 = loft_user_rib(loft_local_u_3, loft_local_a_6);
    return (_e7.origin + (_e7.normal * ((loft_local_r_1 * (1.0 + _e17)) * metal::cos(loft_local_a_6)))) + (_e7.binormal * ((loft_local_r_1 * (0.9 + _e17)) * metal::sin(loft_local_a_6)));
}

Bsdf q_material(
    Row loft_local_self_2,
    metal::float3 loft_local_p_2,
    metal::float3 loft_local_n_4,
    metal::float2 loft_local_uv
) {
    float _e14 = loft_user_wave((12.0 * loft_local_uv.x) + (3.0 * metal::sin(loft_const_TAU * loft_local_uv.y)));
    float _e18 = loft_user_fbm2_(loft_local_p_2.xyz * 7.0);
    float _e23 = loft_user_rib(loft_local_uv.x, loft_const_TAU * loft_local_uv.y);
    float loft_local_ridge = _e23 * 20.0;
    metal::float3 loft_local_base = metal::mix(metal::float3(0.8, 0.62, 0.42), metal::float3(0.42, 0.2, 0.09), (_e14 * 0.7) + (0.3 * _e18)) * loft_local_self_2.r_tint;
    float loft_local_grime = metal::saturate(1.0 - loft_local_ridge) * metal::smoothstep(0.35, 0.75, _e18);
    float loft_local_lip = metal::smoothstep(0.93, 1.0, loft_local_uv.x);
    return Bsdf {metal::mix(loft_local_base, metal::float3(0.12, 0.16, 0.1), loft_local_grime * 0.6), 0.45 + (0.3 * loft_local_grime), 0.0, 0.08 + (0.6 * loft_local_lip), 1.42, 380.0, 0.5 * (1.0 - loft_local_grime), 0.12};
}

float loft_shadow(
    metal::float3 p_1,
    metal::float3 n_7,
    constant Frame& frame,
    metal::depth2d<float, metal::access::sample> shadow_tex,
    metal::sampler shadow_smp
) {
    bool local_7 = {};
    bool local_8 = {};
    bool local_9 = {};
    float s = 0.0;
    uint _e5 = frame.cold.z;
    if (_e5 == 0u) {
        return 1.0;
    }
    metal::float4x4 _e11 = frame.light_vp;
    float _e15 = frame.sun.w;
    metal::float4 q = _e11 * metal::float4(p_1 + (n_7 * (1.5 * _e15)), 1.0);
    metal::float2 uv = metal::float2((q.x * 0.5) + 0.5, 0.5 - (q.y * 0.5));
    if (!(metal::any(uv < metal::float2(0.0)))) {
        local_7 = metal::any(uv > metal::float2(1.0));
    } else {
        local_7 = true;
    }
    bool _e46 = local_7;
    if (!(_e46)) {
        local_8 = q.z > 1.0;
    } else {
        local_8 = true;
    }
    bool _e54 = local_8;
    if (!(_e54)) {
        local_9 = q.z < 0.0;
    } else {
        local_9 = true;
    }
    bool _e62 = local_9;
    if (_e62) {
        return 1.0;
    }
    float texel = 1.0 / static_cast<float>(metal::uint2(shadow_tex.get_width(), shadow_tex.get_height()).x);
    float depth = q.z - 0.0005;
    float _e75 = s;
    float _e83 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(-1.0, -1.0) * texel), depth);
    s = _e75 + _e83;
    float _e85 = s;
    float _e93 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(-1.0, 0.0) * texel), depth);
    s = _e85 + _e93;
    float _e95 = s;
    float _e103 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(-1.0, 1.0) * texel), depth);
    s = _e95 + _e103;
    float _e105 = s;
    float _e113 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(0.0, -1.0) * texel), depth);
    s = _e105 + _e113;
    float _e115 = s;
    float _e123 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(0.0, 0.0) * texel), depth);
    s = _e115 + _e123;
    float _e125 = s;
    float _e133 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(0.0, 1.0) * texel), depth);
    s = _e125 + _e133;
    float _e135 = s;
    float _e143 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(1.0, -1.0) * texel), depth);
    s = _e135 + _e143;
    float _e145 = s;
    float _e153 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(1.0, 0.0) * texel), depth);
    s = _e145 + _e153;
    float _e155 = s;
    float _e163 = shadow_tex.sample_compare(shadow_smp, uv + (metal::float2(1.0, 1.0) * texel), depth);
    s = _e155 + _e163;
    float _e165 = s;
    return _e165 / 9.0;
}

struct shadeInput {
};
[[max_total_threads_per_threadgroup(64)]] kernel void shade(
  metal::uint3 wg [[threadgroup_position_in_grid]]
, metal::uint3 lid [[thread_position_in_threadgroup]]
, device type_1 const& luts [[buffer(5)]]
, constant Frame& frame [[buffer(0)]]
, device type_7 const& loft_params [[buffer(2)]]
, device type_1 const& rows [[buffer(3)]]
, constant KindParams& kp [[buffer(4)]]
, metal::texture2d<uint, metal::access::sample> vis_tex [[texture(0)]]
, metal::texture2d<float, metal::access::write> hdr [[texture(1)]]
, device type_10 const& tiles [[buffer(6)]]
, metal::depth2d<float, metal::access::sample> shadow_tex [[texture(2)]]
, metal::sampler shadow_smp [[sampler(0)]]
, constant _mslBufferSizes& _buffer_sizes [[buffer(7)]]
) {
    bool local = {};
    bool local_1 = {};
    metal::float3 n = {};
    uint _e5 = frame.cold.x;
    if (_e5 == LOFT_NONCE) {
        return;
    }
    uint _e11 = kp.kind_id;
    uint _e15 = frame.size.w;
    uint tile = tiles[metal::min(unsigned((_e11 * _e15) + wg.x), (_buffer_sizes.size7 - 0 - 4) / 4)];
    metal::uint2 px_1 = (metal::uint2(tile & 65535u, tile >> 16u) * 8u) + lid.xy;
    uint _e34 = frame.size.x;
    if (!((px_1.x >= _e34))) {
        uint _e43 = frame.size.y;
        local = px_1.y >= _e43;
    } else {
        local = true;
    }
    bool _e46 = local;
    if (_e46) {
        return;
    }
    uint clamped_lod_e49 = metal::min(uint(0), vis_tex.get_num_mip_levels() - 1);
    metal::uint4 _e49 = vis_tex.read(metal::min(metal::uint2(px_1), metal::uint2(vis_tex.get_width(clamped_lod_e49), vis_tex.get_height(clamped_lod_e49)) - 1), clamped_lod_e49);
    metal::uint2 v_4 = _e49.xy;
    if (!((v_4.x == LOFT_EMPTY))) {
        uint _e62 = kp.kind_id;
        local_1 = (v_4.x >> 24u) != _e62;
    } else {
        local_1 = true;
    }
    bool _e65 = local_1;
    if (_e65) {
        return;
    }
    Row _e69 = load_row(v_4.x & 16777215u, rows, _buffer_sizes);
    metal::float3 _e74 = loft_ray(static_cast<metal::float2>(px_1) + metal::float2(0.5), frame);
    LoftXform _e75 = loft_pose(_e69);
    LoftXform _e76 = loft_xf_inv(_e75);
    metal::float2 uv_1 = metal::float2(static_cast<float>(v_4.y & 65535u), static_cast<float>(v_4.y >> 16u)) / metal::float2(65535.0);
    metal::float3 _e91 = q_surface(_e69, uv_1.x, uv_1.y, luts, _buffer_sizes);
    metal::float3 _e96 = loft_surface_jvp(_e69, uv_1.x, uv_1.y, 1.0, 0.0, luts, _buffer_sizes);
    metal::float3 _e101 = loft_surface_jvp(_e69, uv_1.x, uv_1.y, 0.0, 1.0, luts, _buffer_sizes);
    metal::float3 cr = metal::cross(_e96, _e101);
    metal::float3 nl = cr * metal::rsqrt(metal::max(metal::dot(cr, cr), 0.000000000000000000000000000001));
    metal::float3 _e108 = loft_xf_pt(_e75, _e91);
    metal::float3 _e109 = loft_xf_vec(_e75, nl);
    n = metal::normalize(_e109);
    metal::float3 _e112 = n;
    if (metal::dot(_e112, _e74) > 0.0) {
        metal::float3 _e116 = n;
        n = -(_e116);
    }
    Bsdf _e119 = q_material(_e69, _e91, nl, uv_1);
    metal::float4 _e122 = frame.sun;
    metal::float3 sun = metal::normalize(_e122.xyz);
    metal::float3 _e126 = n;
    metal::float3 _e128 = n;
    float _e129 = loft_shadow(_e108, _e128, frame, shadow_tex, shadow_smp);
    metal::float3 _e130 = loft_user_sun_sky(_e119, _e126, -(_e74), sun, _e129, 1.0, luts, loft_params, _buffer_sizes);
    hdr.write(metal::float4(_e130, 1.0), metal::uint2(px_1));
    return;
}
