// language: metal3.2
#include <metal_stdlib>
#include <simd/simd.h>

using metal::uint;

struct _mslBufferSizes {
    uint size1;
    uint size2;
    uint size3;
    uint size5;
    uint size8;
};

struct Frame {
    metal::float4x4 view_proj;
    metal::float4x4 inv_view_proj;
    metal::float4 eye;
    metal::float4 sun;
    metal::uint4 size;
    metal::uint4 cold;
    metal::float4x4 light_vp;
};
typedef metal::float4 type_5[1];
struct LoftXform {
    metal::float3x3 r;
    metal::float3 t;
};
struct LoftFrame {
    metal::float3 origin;
    metal::float3 tangent;
    metal::float3 normal;
    metal::float3 binormal;
};
struct Row {
    LoftXform r_pose;
    float r_aggro;
    char _pad2[12];
    metal::float3 r_gaze;
    metal::float3 r_tint;
    metal::float3 loft_lo;
    metal::packed_float3 loft_hi;
    float loft_lip;
};
struct KindParams {
    uint kind_id;
    uint base;
    uint n_rows;
    uint pad;
};
typedef float type_9[1];
typedef uint type_10[1];
struct AdvanceArgs {
    uint from_tick;
    uint to_tick;
    uint keep_stride;
};
struct DispatchArgs {
    AdvanceArgs ticks;
    uint first_row;
    uint end_row;
    uint instance_id;
};
struct CheckValue {
    uint tag;
    uint reason;
    float value;
};
constant uint LOFT_NONCE = 4294967295u;
constant uint LOFT_EMPTY = 4294967295u;
constant uint STRIDE = 26u;

metal::float3 loft_xf_pt(
    LoftXform x,
    metal::float3 p
) {
    return (x.r * p) + x.t;
}

metal::float3 loft_xf_vec(
    LoftXform x_1,
    metal::float3 v
) {
    return x_1.r * v;
}

LoftXform loft_xf_inv(
    LoftXform x_2
) {
    metal::float3x3 rt = metal::transpose(x_2.r);
    return LoftXform {rt, -((rt * x_2.t))};
}

LoftXform loft_xf_mul(
    LoftXform a,
    LoftXform b
) {
    return LoftXform {a.r * b.r, (a.r * b.t) + a.t};
}

metal::float3 loft_rot_x(
    metal::float3 p_1,
    float a_1
) {
    float s = metal::sin(a_1);
    float c = metal::cos(a_1);
    return metal::float3(p_1.x, (c * p_1.y) + (s * p_1.z), (c * p_1.z) - (s * p_1.y));
}

metal::float3 loft_rot_y(
    metal::float3 p_2,
    float a_2
) {
    float s_1 = metal::sin(a_2);
    float c_1 = metal::cos(a_2);
    return metal::float3((c_1 * p_2.x) + (s_1 * p_2.z), p_2.y, (c_1 * p_2.z) - (s_1 * p_2.x));
}

metal::float3 loft_rot_z(
    metal::float3 p_3,
    float a_3
) {
    float s_2 = metal::sin(a_3);
    float c_2 = metal::cos(a_3);
    return metal::float3((c_2 * p_3.x) + (s_2 * p_3.y), (c_2 * p_3.y) - (s_2 * p_3.x), p_3.z);
}

float loft_unit(
    float e0_,
    float e1_,
    float x_3
) {
    return metal::clamp((x_3 - e0_) / (e1_ - e0_), 0.0, 1.0);
}

float loft_smootherstep(
    float e0_1,
    float e1_1,
    float x_4
) {
    float _e3 = loft_unit(e0_1, e1_1, x_4);
    return ((_e3 * _e3) * _e3) * ((((6.0 * _e3) - 15.0) * _e3) + 10.0);
}

float loft_dsmoothstep(
    float e0_2,
    float e1_2,
    float x_5
) {
    float _e3 = loft_unit(e0_2, e1_2, x_5);
    return ((6.0 * _e3) * (1.0 - _e3)) / (e1_2 - e0_2);
}

float loft_dsmootherstep(
    float e0_3,
    float e1_3,
    float x_6
) {
    float _e3 = loft_unit(e0_3, e1_3, x_6);
    return ((((30.0 * _e3) * _e3) * (1.0 - _e3)) * (1.0 - _e3)) / (e1_3 - e0_3);
}

metal::float3 loft_ray(
    metal::float2 px,
    constant Frame& frame
) {
    uint _e5 = frame.size.x;
    uint _e16 = frame.size.y;
    metal::float2 ndc = metal::float2(((px.x / static_cast<float>(_e5)) * 2.0) - 1.0, 1.0 - ((px.y / static_cast<float>(_e16)) * 2.0));
    metal::float4x4 _e26 = frame.inv_view_proj;
    metal::float4 far = _e26 * metal::float4(ndc, 1.0, 1.0);
    metal::float4 _e37 = frame.eye;
    return metal::normalize((far.xyz / metal::float3(far.w)) - _e37.xyz);
}

LoftXform loft_xform_yaw(
    metal::float3 o,
    float yaw
) {
    float s_3 = metal::sin(yaw);
    float c_3 = metal::cos(yaw);
    return LoftXform {metal::float3x3(metal::float3(c_3, 0.0, -(s_3)), metal::float3(0.0, 1.0, 0.0), metal::float3(s_3, 0.0, c_3)), o};
}

Row load_row(
    uint i,
    device type_9 const& rows,
    constant _mslBufferSizes& _buffer_sizes
) {
    uint o_1 = i * STRIDE;
    float _e7 = rows[metal::min(unsigned(o_1 + 0u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    float _e12 = rows[metal::min(unsigned(o_1 + 1u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    float _e17 = rows[metal::min(unsigned(o_1 + 2u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    float _e22 = rows[metal::min(unsigned(o_1 + 3u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    float _e27 = rows[metal::min(unsigned(o_1 + 4u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    float _e32 = rows[metal::min(unsigned(o_1 + 5u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    float _e37 = rows[metal::min(unsigned(o_1 + 6u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    float _e42 = rows[metal::min(unsigned(o_1 + 7u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    float _e47 = rows[metal::min(unsigned(o_1 + 8u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    float _e56 = rows[metal::min(unsigned(o_1 + 9u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    float _e61 = rows[metal::min(unsigned(o_1 + 10u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    float _e66 = rows[metal::min(unsigned(o_1 + 11u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    float _e73 = rows[metal::min(unsigned(o_1 + 12u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    float _e78 = rows[metal::min(unsigned(o_1 + 13u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    float _e83 = rows[metal::min(unsigned(o_1 + 14u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    float _e88 = rows[metal::min(unsigned(o_1 + 15u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    float _e94 = rows[metal::min(unsigned(o_1 + 16u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    float _e99 = rows[metal::min(unsigned(o_1 + 17u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    float _e104 = rows[metal::min(unsigned(o_1 + 18u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    float _e110 = rows[metal::min(unsigned(o_1 + 19u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    float _e115 = rows[metal::min(unsigned(o_1 + 20u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    float _e120 = rows[metal::min(unsigned(o_1 + 21u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    float _e126 = rows[metal::min(unsigned(o_1 + 22u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    float _e131 = rows[metal::min(unsigned(o_1 + 23u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    float _e136 = rows[metal::min(unsigned(o_1 + 24u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    float _e142 = rows[metal::min(unsigned(o_1 + 25u), (_buffer_sizes.size2 - 0 - 4) / 4)];
    return Row {LoftXform {metal::float3x3(metal::float3(_e7, _e12, _e17), metal::float3(_e22, _e27, _e32), metal::float3(_e37, _e42, _e47)), metal::float3(_e56, _e61, _e66)}, _e73, {}, metal::float3(_e78, _e83, _e88), metal::float3(_e94, _e99, _e104), metal::float3(_e110, _e115, _e120), metal::float3(_e126, _e131, _e136), _e142};
}

LoftXform loft_pose(
    Row r
) {
    return r.r_pose;
}

LoftFrame loft_lut(
    int i_1,
    uint off,
    uint n,
    device type_9 const& luts,
    constant _mslBufferSizes& _buffer_sizes
) {
    uint o_2 = (off + static_cast<uint>(metal::clamp(i_1, 0, as_type<int>(as_type<uint>(static_cast<int>(n)) - as_type<uint>(1))))) * 12u;
    float _e14 = luts[metal::min(unsigned(o_2), (_buffer_sizes.size5 - 0 - 4) / 4)];
    float _e19 = luts[metal::min(unsigned(o_2 + 1u), (_buffer_sizes.size5 - 0 - 4) / 4)];
    float _e24 = luts[metal::min(unsigned(o_2 + 2u), (_buffer_sizes.size5 - 0 - 4) / 4)];
    float _e30 = luts[metal::min(unsigned(o_2 + 3u), (_buffer_sizes.size5 - 0 - 4) / 4)];
    float _e35 = luts[metal::min(unsigned(o_2 + 4u), (_buffer_sizes.size5 - 0 - 4) / 4)];
    float _e40 = luts[metal::min(unsigned(o_2 + 5u), (_buffer_sizes.size5 - 0 - 4) / 4)];
    float _e46 = luts[metal::min(unsigned(o_2 + 6u), (_buffer_sizes.size5 - 0 - 4) / 4)];
    float _e51 = luts[metal::min(unsigned(o_2 + 7u), (_buffer_sizes.size5 - 0 - 4) / 4)];
    float _e56 = luts[metal::min(unsigned(o_2 + 8u), (_buffer_sizes.size5 - 0 - 4) / 4)];
    float _e62 = luts[metal::min(unsigned(o_2 + 9u), (_buffer_sizes.size5 - 0 - 4) / 4)];
    float _e67 = luts[metal::min(unsigned(o_2 + 10u), (_buffer_sizes.size5 - 0 - 4) / 4)];
    float _e72 = luts[metal::min(unsigned(o_2 + 11u), (_buffer_sizes.size5 - 0 - 4) / 4)];
    return LoftFrame {metal::float3(_e14, _e19, _e24), metal::float3(_e30, _e35, _e40), metal::float3(_e46, _e51, _e56), metal::float3(_e62, _e67, _e72)};
}

LoftFrame loft_blend(
    int i_2,
    uint off_1,
    uint n_1,
    metal::float4 w,
    device type_9 const& luts,
    constant _mslBufferSizes& _buffer_sizes
) {
    LoftFrame _e6 = loft_lut(as_type<int>(as_type<uint>(i_2) - as_type<uint>(1)), off_1, n_1, luts, _buffer_sizes);
    LoftFrame _e7 = loft_lut(i_2, off_1, n_1, luts, _buffer_sizes);
    LoftFrame _e10 = loft_lut(as_type<int>(as_type<uint>(i_2) + as_type<uint>(1)), off_1, n_1, luts, _buffer_sizes);
    LoftFrame _e13 = loft_lut(as_type<int>(as_type<uint>(i_2) + as_type<uint>(2)), off_1, n_1, luts, _buffer_sizes);
    return LoftFrame {(((_e6.origin * w.x) + (_e7.origin * w.y)) + (_e10.origin * w.z)) + (_e13.origin * w.w), (((_e6.tangent * w.x) + (_e7.tangent * w.y)) + (_e10.tangent * w.z)) + (_e13.tangent * w.w), (((_e6.normal * w.x) + (_e7.normal * w.y)) + (_e10.normal * w.z)) + (_e13.normal * w.w), (((_e6.binormal * w.x) + (_e7.binormal * w.y)) + (_e10.binormal * w.z)) + (_e13.binormal * w.w)};
}

int naga_f2i32(float value) {
    return static_cast<int>(metal::clamp(value, -2147483600.0, 2147483500.0));
}

LoftFrame loft_sample(
    uint off_2,
    uint n_2,
    float lo,
    float hi,
    float t,
    device type_9 const& luts,
    constant _mslBufferSizes& _buffer_sizes
) {
    float s_4 = ((t - lo) / (hi - lo)) * static_cast<float>(n_2 - 1u);
    float i_3 = metal::clamp(metal::floor(s_4), 0.0, static_cast<float>(n_2 - 1u));
    float f = s_4 - i_3;
    float g = 1.0 - f;
    LoftFrame _e58 = loft_blend(naga_f2i32(i_3), off_2, n_2, metal::float4(((g * g) * g) / 6.0, (((((3.0 * f) * f) * f) - ((6.0 * f) * f)) + 4.0) / 6.0, ((((((-3.0 * f) * f) * f) + ((3.0 * f) * f)) + (3.0 * f)) + 1.0) / 6.0, ((f * f) * f) / 6.0), luts, _buffer_sizes);
    return _e58;
}

LoftFrame loft_dsample(
    uint off_3,
    uint n_3,
    float lo_1,
    float hi_1,
    float t_1,
    float dt,
    device type_9 const& luts,
    constant _mslBufferSizes& _buffer_sizes
) {
    float s_5 = ((t_1 - lo_1) / (hi_1 - lo_1)) * static_cast<float>(n_3 - 1u);
    float i_4 = metal::clamp(metal::floor(s_5), 0.0, static_cast<float>(n_3 - 1u));
    float f_1 = s_5 - i_4;
    float g_1 = 1.0 - f_1;
    float k = (static_cast<float>(n_3 - 1u) / (hi_1 - lo_1)) * dt;
    LoftFrame _e56 = loft_blend(naga_f2i32(i_4), off_3, n_3, metal::float4((-(g_1) * g_1) / 2.0, (((3.0 * f_1) * f_1) - (4.0 * f_1)) / 2.0, ((((-3.0 * f_1) * f_1) + (2.0 * f_1)) + 1.0) / 2.0, (f_1 * f_1) / 2.0) * k, luts, _buffer_sizes);
    return _e56;
}

float det_sin(
    float a_4
) {
    float p_4 = {};
    float r_2 = metal::fma(-(metal::floor((a_4 / 6.2831855) + 0.5)), 6.2831855, a_4);
    float x_12 = metal::sign(r_2) * metal::min(metal::abs(r_2), 3.1415927 - metal::abs(r_2));
    float z = x_12 * x_12;
    p_4 = metal::fma(z, 0.00000000016059044, -0.000000025052108);
    float _e20 = p_4;
    p_4 = metal::fma(z, _e20, 0.0000027557319);
    float _e23 = p_4;
    p_4 = metal::fma(z, _e23, -0.0001984127);
    float _e26 = p_4;
    p_4 = metal::fma(z, _e26, 0.008333334);
    float _e29 = p_4;
    p_4 = metal::fma(z, _e29, -0.16666667);
    float _e32 = p_4;
    return x_12 * metal::fma(z, _e32, 1.0);
}

float det_cos(
    float a_5
) {
    float _e3 = det_sin(a_5 + 1.5707964);
    return _e3;
}

float det_atan2_(
    float y,
    float x_7
) {
    float p_5 = {};
    float v_1 = {};
    float hi_2 = metal::max(metal::abs(x_7), metal::abs(y));
    if (hi_2 == 0.0) {
        return 0.0;
    }
    float a_6 = metal::min(metal::abs(x_7), metal::abs(y)) / hi_2;
    bool shift = a_6 > 0.41421357;
    float r_3 = shift ? ((a_6 - 1.0) / (a_6 + 1.0)) : a_6;
    float z_1 = r_3 * r_3;
    p_5 = metal::fma(z_1, 0.07692308, -0.09090909);
    float _e25 = p_5;
    p_5 = metal::fma(z_1, _e25, 0.11111111);
    float _e28 = p_5;
    p_5 = metal::fma(z_1, _e28, -0.14285715);
    float _e31 = p_5;
    p_5 = metal::fma(z_1, _e31, 0.2);
    float _e34 = p_5;
    p_5 = metal::fma(z_1, _e34, -0.33333334);
    float _e37 = p_5;
    v_1 = metal::fma(r_3, metal::fma(z_1, _e37, 1.0), shift ? 0.7853982 : 0.0);
    if (metal::abs(y) > metal::abs(x_7)) {
        float _e48 = v_1;
        v_1 = 1.5707964 - _e48;
    }
    if (x_7 < 0.0) {
        float _e53 = v_1;
        v_1 = 3.1415927 - _e53;
    }
    float _e56 = v_1;
    float _e57 = v_1;
    return (y < 0.0) ? -(_e57) : _e56;
}

float det_acos(
    float x_8
) {
    float _e7 = det_atan2_(metal::sqrt((1.0 - x_8) * (1.0 + x_8)), x_8);
    return _e7;
}

float det_exp_poly(
    float r_1
) {
    float p_6 = {};
    p_6 = metal::fma(r_1, 0.0001984127, 0.0013888889);
    float _e5 = p_6;
    p_6 = metal::fma(r_1, _e5, 0.008333334);
    float _e8 = p_6;
    p_6 = metal::fma(r_1, _e8, 0.041666668);
    float _e11 = p_6;
    p_6 = metal::fma(r_1, _e11, 0.16666667);
    float _e14 = p_6;
    p_6 = metal::fma(r_1, _e14, 0.5);
    float _e18 = p_6;
    return metal::fma(r_1 * r_1, _e18, 1.0 + r_1);
}

int naga_neg(int val) {
    return as_type<int>(-as_type<uint>(val));
}

float det_exp_subnormal(
    float x_9
) {
    int k_1 = naga_f2i32(metal::floor(metal::fma(x_9, 1.442695, 0.5)));
    float _e10 = det_exp_poly(metal::fma(static_cast<float>(naga_neg(k_1)), 0.6931472, x_9));
    return _e10 * as_type<float>(static_cast<uint>(as_type<int>(as_type<uint>(k_1) + as_type<uint>(127))) << 23u);
}

float det_exp(
    float x_10
) {
    if (x_10 < -103.97208) {
        return 0.0;
    }
    if (x_10 > 88.72283) {
        return as_type<float>(2139095040u);
    }
    int k_2 = metal::clamp(naga_f2i32(metal::floor(metal::fma(x_10, 1.442695, 0.5))), -126, 127);
    float r_4 = metal::fma(static_cast<float>(naga_neg(k_2)), 0.6931472, x_10);
    if (r_4 < -0.346574) {
        float _e24 = det_exp_subnormal(r_4);
        return as_type<float>(8388608u) * _e24;
    }
    float _e32 = det_exp_poly(r_4);
    return as_type<float>(static_cast<uint>(as_type<int>(as_type<uint>(k_2) + as_type<uint>(127))) << 23u) * _e32;
}

float det_log(
    float x_11
) {
    float p_7 = {};
    if (x_11 == 0.0) {
        return as_type<float>(4286578688u);
    }
    if (x_11 < 0.0) {
        return as_type<float>(2143289344u);
    }
    if (x_11 == as_type<float>(2139095040u)) {
        return x_11;
    }
    bool small = x_11 < as_type<float>(8388608u);
    uint bits = as_type<uint>(small ? (x_11 * 8388608.0) : x_11);
    int k_3 = as_type<int>(as_type<uint>(static_cast<int>(bits >> 23u)) - as_type<uint>(small ? 150 : 127));
    float m = as_type<float>((bits & 8388607u) | 1065353216u);
    float z_2 = (m - 1.0) / (m + 1.0);
    float w_1 = z_2 * z_2;
    p_7 = metal::fma(w_1, 0.07692308, 0.09090909);
    float _e41 = p_7;
    p_7 = metal::fma(w_1, _e41, 0.11111111);
    float _e44 = p_7;
    p_7 = metal::fma(w_1, _e44, 0.14285715);
    float _e47 = p_7;
    p_7 = metal::fma(w_1, _e47, 0.2);
    float _e50 = p_7;
    p_7 = metal::fma(w_1, _e50, 0.33333334);
    float _e56 = p_7;
    return metal::fma(static_cast<float>(k_3), 0.6931472, (2.0 * z_2) * metal::fma(w_1, _e56, 1.0));
}

float motion_loft_user_wave(
    float loft_local_a
) {
    float _e1 = det_sin(loft_local_a);
    return 0.5 + (0.5 * _e1);
}

Row law_pulse(
    Row initial,
    float loft_local_dt
) {
    Row loft_local_h = {};
    loft_local_h = initial;
    float _e5 = loft_local_h.r_aggro;
    float _e7 = loft_local_h.r_aggro;
    float _e8 = motion_loft_user_wave(_e7);
    loft_local_h.r_aggro = _e5 + (loft_local_dt * _e8);
    Row _e11 = loft_local_h;
    return _e11;
}

struct advanceInput {
};
[[max_total_threads_per_threadgroup(64)]] kernel void advance(
  metal::uint3 gid [[thread_position_in_grid]]
, device type_9& rows [[buffer(4)]]
, device DispatchArgs const& loft_advance_args [[buffer(3)]]
, constant _mslBufferSizes& _buffer_sizes [[buffer(5)]]
) {
    float loft_tick_time = {};
    uint loft_tick = {};
    Row state = {};
    uint step = 0u;
    uint _e4 = loft_advance_args.first_row;
    uint i_5 = gid.x + _e4;
    uint _e8 = loft_advance_args.end_row;
    if (i_5 >= _e8) {
        return;
    }
    Row _e10 = load_row(i_5, rows, _buffer_sizes);
    state = _e10;
    uint from_tick = loft_advance_args.ticks.from_tick;
    uint to_tick = loft_advance_args.ticks.to_tick;
    uint2 loop_bound = uint2(4294967295u);
    bool loop_init = true;
    while(true) {
        if (metal::all(loop_bound == uint2(0u))) { break; }
        loop_bound -= uint2(loop_bound.y == 0u, 1u);
        if (!loop_init) {
            uint _e41 = step;
            step = _e41 + 1u;
        }
        loop_init = false;
        uint _e23 = step;
        if (_e23 < 64u) {
        } else {
            break;
        }
        {
            uint _e26 = step;
            if (_e26 >= (to_tick - from_tick)) {
                break;
            }
            uint _e30 = step;
            loft_tick = (from_tick + _e30) + 1u;
            uint _e36 = loft_tick;
            loft_tick_time = static_cast<float>(_e36) * 0.008333334;
            Row _e39 = state;
            Row _e40 = law_pulse(_e39, 0.008333334);
            state = _e40;
        }
    }
    float _e51 = state.r_aggro;
    rows[metal::min(unsigned((i_5 * STRIDE) + 12u), (_buffer_sizes.size2 - 0 - 4) / 4)] = _e51;
    return;
}
