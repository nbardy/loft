#!/bin/bash
set -euo pipefail
cli="$1"
p="$PWD/out/meta/bk1-scientist"
mkdir -p "$p/msl"
# Compile one extra fixed-tick entry and capture both its rendering and motion libraries.
LOFT_PROBE_MSL="$p/msl" "$cli" still "$p/wave.loft" "$p/wave.png" --t 0.008333333 >"$p/capture.log" 2>&1
for scene in hermit coral_shrine; do
    n=300
    args=(--set count=20)
    if [[ $scene == coral_shrine ]]; then n=100; args=(--set shrine_distance=6.4 --time 0); fi
    for arm in A1 B1 B2 A2; do
        opts=(LOFT_PROBE_MSL="$p/msl")
        if [[ $arm == B* ]]; then opts+=(LOFT_PROBE_SAFE=1); fi
        env "${opts[@]}" "$cli" profile "engines/$scene.loft" "${args[@]}" \
            --size 1280x800 --timestamps ring --warmup 30 --frames "$n" --json "$p/$scene-$arm.json" >"$p/$scene-$arm.log" 2>&1
    done
done
