from math import ceil
from pathlib import Path
import json, statistics
p=Path(__file__).resolve().parent
def p95(xs): return sorted(xs)[ceil(.95*len(xs))-1]
for scene in ('hermit','coral_shrine'):
 arms=[json.loads((p/f'{scene}-{arm}.json').read_text()) for arm in ('A1','B1','B2','A2')]
 raw={}
 for label,a in zip(('A1','B1','B2','A2'),arms):
  period=a['gpu_frame_ms'][0]/(a['frame_stamps'][0]['ticks'][-1]-a['frame_stamps'][0]['ticks'][0])
  elapsed=[(max(s['ticks'][1::2])-min(s['ticks'][::2]))*period for s in a['frame_stamps']]
  raw[label]=p95(elapsed)
  print(scene,label,'p95',round(raw[label],4),'CLI',round(p95(a['gpu_frame_ms']),4),'tri',round(a['control_p50_ms'],4),'cmds',set(f['commands'] for f in a['frame_stamps']),'period ns',period*1e6)
 assert all(a['shader_sha256']==arms[0]['shader_sha256'] and a['frame_time_bits']==arms[0]['frame_time_bits'] for a in arms)
 A=statistics.mean([raw['A1'],raw['A2']]); B=statistics.mean([raw['B1'],raw['B2']])
 print('mean block p95',A,B,'delta',B-A, (B/A-1)*100,'AA diff',raw['A2']-raw['A1'])
