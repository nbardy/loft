@fragment fn fs(v: VsOut) -> FsOut {
  if frame.cold.x == LOFT_NONCE { discard; }
  let row = load_row(v.row);
  var ro = frame.eye.xyz;
  var rd = normalize(v.wp - ro);
  // The sun's view is orthographic: every ray runs along `eye.xyz`, starting outside the row's bound.
  if frame.cold.y == 1u {
    rd = frame.eye.xyz;
    ro = v.wp - rd * (2.0 * length(row.loft_hi - row.loft_lo) + 1.0);
  }
  let span = loft_box(ro, rd, row.loft_lo, row.loft_hi);
  let xf = loft_xf_inv(loft_pose(row));
  let lro = loft_xf_pt(xf, ro);
  let lrd = loft_xf_vec(xf, rd);
  // Closed form: the author's `visible` query, in the kind's space (a rigid pose keeps t).
  let t = q_visible(row, lro, lrd);
  if t < 0.0 { discard; }
  let clip = frame.view_proj * vec4<f32>(ro + rd * t, 1.0);
  return FsOut(vec2<u32>((kp.kind_id << 24u) | v.row, bitcast<u32>(t)), clip.z / clip.w);
}